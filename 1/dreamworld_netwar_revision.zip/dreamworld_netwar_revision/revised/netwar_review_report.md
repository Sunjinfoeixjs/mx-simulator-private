# netwar C2S/S2C 协议结构修订报告

## 范围与方法

本次以 `protocol_functions.json` 的 `modules.netwar.py` 为函数字段提取来源，以 `protocol_map.json` 核对 Opcode/路由，以 `protocol_s2c_full.txt` 的头部说明解释路由 tag。原始 7 个文件已逐字节备份到 `backup/`。修订副本只添加审计字段，不删除原始字段或猜测缺失语义。

## 统计

- C2S：19 个函数
- S2C：22 个处理函数
- GS2C：1 个函数
- `protocol_map.json` 中 `netwar` 的 S2C 路由：22 条
- S2C 路由 tag 分布：{'16': 4, '18': 18}
- C2S 在本模块内共享 Opcode：{"176": ["C2SWarLook", "C2SLookWarrior"]}

## 已做的修改

1. `revised/combat_opcodes_fields.json`：保留原有 `fields`、`total_bytes` 与键结构，增加 `args`、`direction`、`module`、`opcode_scope`、源码提取字段对照及审计标记。
2. `revised/protocol_functions.json`：保留原字段，给 `netwar.py` 的函数增加 `review` 标记，说明路由是否匹配、字段名是否缺失及已知疑点。
3. 新增 `revised/netwar_protocol.json`：统一 C2S/S2C/GS2C 结构，标出路由 tag、原始字段宽度、字段名提取状态和问题清单。
4. `backup/`：保留原始 7 个文件，便于回滚和逐项比对。

## 必须保留为待验证的问题

### 1. `C2SWarSummPerform`

函数参数为 `id, target, perform`，但提取字段只有 `target`（1 字节）和 `perform`（2 字节）。不能凭参数列表判断 `id` 必须在网络上发送。需要查看实际序列化代码或合法测试数据包。

### 2. Opcode 176 的双重定义

`C2SWarLook`（参数名 `id`）与 `C2SLookWarrior`（参数名 `order`）都映射到 `C2S_WAR_LOOK`/176，字段宽度都是 1 字节。保留两者，不合并，不替换语义。

### 3. `C2SSendSign` 动态字符串

`combat_opcodes_fields.json` 记为 `N:len`，函数提取记录记为 `len(msg)`。两者都指向动态长度，但不能由此推断字符串编码、长度前缀或底层封包如何界定消息边界。

### 4. S2C 字段名缺失

下列 S2C 函数至少有一个字段的 `value` 为空：

`S2CWarStart`, `S2CWarTurn`, `S2CWarAdd`, `S2CWarDel`, `S2CWarAttackNormal`, `S2CWarAttackNormalEnd`, `S2CWarAttackConverg`, `S2CWarProtect`, `S2CWarPerform`, `S2CWarWState`, `S2CWarAddon`, `S2CWarWeather`, `S2CWarPlayerChat`, `S2CWarHPPercent`, `S2CWarSummon`, `S2CWarSummonCatch`, `S2CWarONACT`, `S2CWarSign`, `S2CWarChildSkill`, `S2CWarCalledPet`, `S2CChangeAction`。

字段保留为匿名槽位（`name: null`），没有根据函数名猜测字段名称。

### 5. `GS2CWarShape` 路由缺失

函数索引中有该函数，但 `protocol_map.json` 未找到对应 `netwar` 路由。不能擅自分配 tag 或 opcode；需查调用/分发路径。

## 验收结果

- JSON 语法校验：待脚本完成后记录
- 原始字段保留：是（修订文件为添加审计信息的副本）
- 猜测填充 S2C 字段名：否
- 自动改写未知的 opcode 语义：否
- 网络封包长度、字节序、字符串编码：未推断

## 下一步测试建议

1. 为 `C2SWarAttack`、`C2SWarPerform`、`C2SWarDefend` 建立最小编码/解码回环测试。
2. 验证 Opcode 176 的两个调用点，确认它们是别名、不同场景还是提取命名冲突。
3. 检查 `C2SWarSummPerform` 的序列化函数，确认 `id` 是否进入实际写包流。
4. 对 S2C 路由 tag 16/18 的合法样本做字段边界标注，再逐步补齐字段名。
5. 记录战斗开始、回合、行动、状态变更、战斗结束的实际消息顺序；当前静态清单不足以证明完整时序。
