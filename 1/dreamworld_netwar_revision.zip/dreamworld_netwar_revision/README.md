# Dream World 2013 netwar 修订包

- `backup/`：本轮涉及的 7 个原始文件的原样备份。
- `revised/combat_opcodes_fields.json`：向原战斗 C2S 字段表添加了参数对照和审计标记，保留原有字段。
- `revised/protocol_functions.json`：只在 `netwar.py` 函数记录上添加 review 注释，不改写原字段。
- `revised/netwar_protocol.json`：统一的 netwar C2S/S2C/GS2C 结构视图。
- `revised/netwar_review_report.md`：问题、修改内容与验证建议。

注意：原始聊天上传附件本身不会被覆盖；这里提供可替换/可比对的修订副本。所有未知字段语义均保留为未知。
