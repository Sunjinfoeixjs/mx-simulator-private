# Patch notes

## tap.py overlay coverage

- Added opcode 118: `GS2CWarShape`, common live layout `id:u8 + shape:u16le + desc:UnpackDesc + name:GBK C-string`.
- Added opcode 120: `S2CWarAttackConverg`, layout `att_id:u8 + vic_id:u8`.
- Added an explicit caveat for replay-mode `desc`: `g_ReplayVer == 1` reads 2 bytes; `g_ReplayVer == 2` reads 4 bytes; otherwise the client calls `prop.UnpackDesc`.
- No change to original Library `tap.py`; this package contains a revised copy and a byte-for-byte backup.
