import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
CODEC_PATH = ROOT / "revised" / "netwar_codec.py"
spec = importlib.util.spec_from_file_location("netwar_codec_core_under_test", CODEC_PATH)
codec = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = codec
spec.loader.exec_module(codec)


def decode_one(packet, direction):
    decoder = codec.StreamFrameDecoder(direction)
    frames = decoder.feed(packet)
    if len(frames) != 1:
        raise AssertionError(f"expected one frame, got {len(frames)}")
    return frames[0]


class FramingTests(unittest.TestCase):
    def test_c2s_fragmented_frame(self):
        packet = codec.encode_c2s_command("C2SWarPerform", id=7, perform=0x1234)
        decoder = codec.StreamFrameDecoder("C2S")
        self.assertEqual(decoder.feed(packet[:2]), [])
        self.assertEqual(decoder.buffered_bytes, 2)
        frames = decoder.feed(packet[2:])
        self.assertEqual(len(frames), 1)
        self.assertEqual((frames[0].opcode, frames[0].body), (161, b"\x07\x34\x12"))

    def test_s2c_small_frame(self):
        packet = codec.encode_s2c_war_end()
        frame = decode_one(packet, "S2C")
        self.assertEqual((frame.opcode, frame.body), (113, b""))

    def test_extended_c2s_and_s2c(self):
        body = bytes(range(250)) + bytes(range(50))
        for direction, packet in (
            ("C2S", codec.encode_c2s_frame(250, body)),
            ("S2C", codec.encode_s2c_frame(250, body)),
        ):
            frame = decode_one(packet, direction)
            self.assertEqual(frame.opcode, 250)
            self.assertEqual(frame.body, body)

    def test_multiple_frames_in_one_read(self):
        p1 = codec.encode_c2s_frame(160, b"\x05")
        p2 = codec.encode_c2s_frame(163, b"")
        frames = codec.StreamFrameDecoder("C2S").feed(p1 + p2)
        self.assertEqual([(f.opcode, f.body) for f in frames], [(160, b"\x05"), (163, b"")])


class CommandCodecTests(unittest.TestCase):
    def test_u16_command_is_little_endian(self):
        packet = codec.encode_c2s_command("C2SWarPerform", id=4, perform=0x1234)
        frame = decode_one(packet, "C2S")
        self.assertEqual(frame.body, b"\x04\x34\x12")
        decoded = codec.decode_c2s_command(frame.opcode, frame.body)
        self.assertEqual((decoded["id"], decoded["perform"]), (4, 0x1234))

    def test_summon_perform_does_not_add_context_id(self):
        packet = codec.encode_c2s_war_summ_perform(target=9, perform=0x1234)
        frame = decode_one(packet, "C2S")
        self.assertEqual(frame.opcode, 169)
        self.assertEqual(frame.body, b"\x09\x34\x12")
        decoded = codec.decode_c2s_command(169, frame.body)
        self.assertEqual((decoded["target"], decoded["perform"]), (9, 0x1234))
        self.assertNotIn("id", decoded)

    def test_opcode_176_requires_variant(self):
        ambiguous = codec.decode_c2s_command(176, b"\x07")
        self.assertEqual(ambiguous["decode_status"], "ambiguous_variant")
        by_id = codec.decode_c2s_command(176, b"\x07", variant="C2SWarLook")
        by_order = codec.decode_c2s_command(176, b"\x07", variant="C2SLookWarrior")
        self.assertEqual(by_id["id"], 7)
        self.assertEqual(by_order["order"], 7)

    def test_conditional_summon_layout(self):
        packet = codec.encode_c2s_command("C2SWarSummon", op=0, id=0x12345678)
        frame = decode_one(packet, "C2S")
        self.assertEqual(frame.body, b"\x00\x78\x56\x34\x12")
        decoded = codec.decode_c2s_command(166, frame.body)
        self.assertEqual(decoded["id"], 0x12345678)

    def test_variable_string_command_is_not_guessed(self):
        with self.assertRaises(codec.UnverifiedSchemaError):
            codec.encode_c2s_command("C2SSendSign", msg=1)

    def test_integer_overflow_is_rejected(self):
        with self.assertRaises(codec.ProtocolError):
            codec.encode_c2s_command("C2SWarAttack", id=256)


class S2CCodecTests(unittest.TestCase):
    def test_war_start_scene_offset(self):
        packet = codec.encode_s2c_war_start(scene=42, alineup=1, elineup=3, wtype=2, x=100, y=200)
        frame = decode_one(packet, "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual(decoded["scene_field"], 42)
        self.assertEqual(decoded["scene"], 1043)
        self.assertEqual((decoded["x"], decoded["y"]), (100, 200))

    def test_wstate_signed_damage_roundtrip(self):
        packet = codec.encode_s2c_wstate(3, hurt=1, life=0, ward=1, hp_change=50)
        frame = decode_one(packet, "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual((decoded["id"], decoded["hurt"], decoded["ward"], decoded["hp_chg"]),
                         (3, 1, 1, 50))
        packet = codec.encode_s2c_wstate(3, hurt=1, life=0, ward=1, hp_change=-50)
        frame = decode_one(packet, "S2C")
        self.assertEqual(codec.decode_s2c_war(frame.opcode, frame.body)["hp_chg"], -50)

    def test_war_perform_variable_targets(self):
        packet = codec.encode_s2c_war_perform(1, 0x1234, [2, 3, 4])
        frame = decode_one(packet, "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual(decoded["pid"], 0x1234)
        self.assertEqual(decoded["vic_ids"], [2, 3, 4])

    def test_war_add_msb_flags_and_gbk_name(self):
        packet = codec.encode_s2c_war_add(1, 2010, allied=True, name="野猪")
        frame = decode_one(packet, "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertTrue(decoded["allied"])
        self.assertEqual(decoded["shape"], 2010)
        self.assertEqual(decoded["warrior_name"], "野猪")

    def test_turn_flag_is_raw_boolean_marker(self):
        frame = decode_one(codec.encode_s2c_war_turn(1), "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertTrue(decoded["lastcmd"])
        self.assertEqual(decoded["lastcmd_raw"], 1)
        self.assertIn("contextual", decoded["decode_status"])

    def test_opcode_120_callback_layout(self):
        frame = decode_one(codec.encode_s2c_war_attack_converg(4, 9), "S2C")
        decoded = codec.decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual((decoded["name"], decoded["att_id"], decoded["vic_id"]),
                         ("S2CWarAttackConverg", 4, 9))

if __name__ == "__main__":
    unittest.main(verbosity=2)
