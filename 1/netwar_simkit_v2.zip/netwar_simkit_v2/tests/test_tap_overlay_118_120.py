import importlib.util
import json
import pathlib
import sys
import types
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
REVISED = ROOT / "revised"

# tap.py imports the project LZSS module at import time. These tests cover only
# schema parsing, so provide a no-op stub instead of requiring the whole server.
sys.modules.setdefault("lzss", types.SimpleNamespace(compress=lambda b: b, decompress=lambda b: b))

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

tap = load_module("tap_under_test", REVISED / "tap.py")
codec = load_module("netwar_codec_under_test", REVISED / "netwar_codec.py")

class TapOverlayTests(unittest.TestCase):
    def test_opcode_118_overlay_is_routed_to_shape_callback(self):
        self.assertEqual(tap._OV_S2C[118][0], "GS2CWarShape")
        self.assertEqual(tap.OVERLAY_NAME["S2C"][118], "GS2CWarShape")
        fields = tap.OVERLAY["S2C"][118]
        self.assertEqual([f["value"] for f in fields], ["id", "shape", "desc", "name"])

    def test_opcode_118_common_live_empty_desc_decodes_exactly(self):
        body = bytes([7]) + (2010).to_bytes(2, "little") + b"\x00" + "野猪".encode("gbk") + b"\x00"
        rows, tail, note, consumed = tap.decode_fields(tap.OVERLAY["S2C"][118], body)
        values = {row.get("name"): row.get("value") for row in rows}
        self.assertEqual(values["id"], 7)
        self.assertEqual(values["shape"], 2010)
        self.assertEqual(values["name"], "野猪")
        self.assertEqual(tail, b"")
        self.assertEqual(note, "")
        self.assertEqual(consumed, len(body))

    def test_opcode_118_missing_nul_is_reported_not_silently_fit(self):
        body = bytes([7]) + (2010).to_bytes(2, "little") + b"\x00" + "野猪".encode("gbk")
        result = tap.decode_best([tap.OVERLAY["S2C"][118]], body)
        self.assertFalse(result["fit"])
        self.assertIn("结尾", result["note"])

    def test_opcode_120_overlay_is_two_unsigned_bytes(self):
        self.assertEqual(tap._OV_S2C[120][0], "S2CWarAttackConverg")
        fields = tap.OVERLAY["S2C"][120]
        self.assertEqual([(f["value"], f["kind"], f["size"]) for f in fields],
                         [("att_id", "I", "1"), ("vic_id", "I", "1")])
        result = tap.decode_best([fields], bytes([4, 9]))
        self.assertTrue(result["fit"])
        self.assertEqual([row["value"] for row in result["rows"]], [4, 9])

    def test_overlay_names_match_client_net_py_route_table(self):
        net_py = (ROOT / "reference" / "net.py").read_text(encoding="utf-8")
        routes = tap._parse_s2c_routes(net_py)
        self.assertEqual(routes[118], ("netwar", "GS2CWarShape"))
        self.assertEqual(routes[120], ("netwar", "S2CWarAttackConverg"))
        self.assertEqual(tap.OVERLAY_NAME["S2C"][118], routes[118][1])
        self.assertEqual(tap.OVERLAY_NAME["S2C"][120], routes[120][1])

    def test_codec_and_tap_agree_on_opcode_120(self):
        result = codec.decode_s2c_war(120, bytes([4, 9]))
        self.assertEqual(result["name"], tap.OVERLAY_NAME["S2C"][120])
        self.assertEqual((result["att_id"], result["vic_id"]), (4, 9))

    def test_codec_and_tap_agree_on_opcode_118_common_live_layout(self):
        body = bytes([7]) + (2010).to_bytes(2, "little") + b"\x00" + "野猪".encode("gbk") + b"\x00"
        result = codec.decode_s2c_war(118, body)
        self.assertEqual(result["name"], tap.OVERLAY_NAME["S2C"][118])
        self.assertEqual((result["id"], result["shape"], result["warrior_name"]), (7, 2010, "野猪"))

    def test_schema_keeps_replay_descriptor_caveat_explicit(self):
        note = tap._OV_NOTE[118]
        self.assertIn("g_ReplayVer", note)
        self.assertIn("2/4", note)

if __name__ == "__main__":
    unittest.main(verbosity=2)
