import importlib.util
import json
import pathlib
import sys
import types
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
REVISED = ROOT / "revised"
sys.modules.setdefault("lzss", types.SimpleNamespace(compress=lambda b: b, decompress=lambda b: b))
spec = importlib.util.spec_from_file_location("tap_routes_under_test", REVISED / "tap.py")
tap = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = tap
spec.loader.exec_module(tap)

class SchemaRouteTests(unittest.TestCase):
    def test_json_schema_names_match_client_route_names(self):
        schema = json.loads((REVISED / "netwar_schema.json").read_text(encoding="utf-8"))
        net_py = (ROOT / "reference" / "net.py").read_text(encoding="utf-8")
        routes = tap._parse_s2c_routes(net_py)
        self.assertEqual(schema["S2C_war"]["118"]["name"], routes[118][1])
        self.assertEqual(schema["S2C_war"]["120"]["name"], routes[120][1])

    def test_ambiguous_wire_shapes_remain_distinct_command_names(self):
        codec = json.loads((REVISED / "netwar_schema.json").read_text(encoding="utf-8"))
        names = [name for name, item in codec["C2S_commands"].items() if item["opcode"] == 176]
        self.assertIn("C2SWarLook", names)
        self.assertIn("C2SLookWarrior", names)

    def test_schema_status_records_overlay_fix_without_claiming_live_test(self):
        schema = json.loads((REVISED / "netwar_schema.json").read_text(encoding="utf-8"))
        self.assertIn("revision adds opcode 118/120 overlays", schema["source_verification_status"])
        self.assertIn("no live-client interoperability test claimed", schema["source_verification_status"])
        item = next(x for x in schema["critical_ambiguities"] if x["subject"] == "S2C overlay coverage")
        self.assertIn("overlay gap closed", item["status"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
