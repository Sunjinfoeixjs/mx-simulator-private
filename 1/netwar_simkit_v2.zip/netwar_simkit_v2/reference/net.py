# uncompyle6 version 3.9.3
# Python bytecode version base 2.6 (62161)
# Decompiled from: Python 3.8.10 (tags/v3.8.10:3d8993a, May  3 2021, 11:48:03) [MSC v.1928 64 bit (AMD64)]
# Embedded file name: script\net.py
from C_net import *
import C_object
C2S_LOGIN_ACCOUNT_ENTER = 1
C2S_LOGIN_PLAYER_ENTER = 2
C2S_LOGIN_PLAYER_ADD = 3
C2S_LOGIN_QUEUE = 4
C2S_ACCOUNT_MANAGE = 5
C2GS_PBZLIST = 6
C2S_PING = 8
C2S_LOGIN_LOCALPW = 9
C2S_RESULT = 10
C2S_DuoYiTong = 11
C2S_Mobile = 12
C2S_BACLLIST = 14
C2S_TIME = 15
C2S_PROP_POINT = 16
C2S_PROP_LEVELUP = 17
C2S_PROP_SWITCH = 18
C2S_DIY_MAGIC = 19
C2S_PLAYER_PHOTO = 20
C2GS_PLAYER_SYSSWITCH = 21
C2S_PLAYER_LOOK = 22
C2S_PLAYER_IB = 23
GS2C_PLAYER_IB = 24
C2S_ITEM_GET = 32
C2S_ITEM_DRAG = 33
C2S_ITEM_USE = 34
C2S_ITEM_STRING = 35
C2S_ITEM_FULL_USE = 36
C2S_ANSWER_BIND = 37
C2S_ITEM_LOCK = 38
GS2C_ZHIDAO = 181
C2S_GET_TASK = 48
C2S_GIVEUP_TASK = 49
C2S_FRIEND = 50
C2S_HERO_CLOSE = 51
C2S_HERO_SALE = 52
C2S_GET_SALE_HIS = 53
C2S_MAP_MOVE = 54
C2S_MAP_SYN_DIREMOTE = 55
C2S_BOOTH_ADD = 56
C2GS_ROLESALE = 59
C2GS_TIME = 61
C2S_PLAYER_TRADE = 64
C2GS_SHOP = 65
C2S_HERO_BLOCK = 66
C2S_CHANGE_TITLE = 67
C2S_CHANGE_SHORTCUT = 68
C2S_PET_REFINE = 69
C2S_HOUSE = 70
C2S_STOREHOUSE = 71
C2S_PLAYER_TEAM = 72
C2S_PLAYER_DRUG = 73
C2S_GROUP_STOCK = 74
C2S_STOCK_OPERATE = 75
C2S_COOK = 76
C2S_CLOSE_MINIGAME = 77
C2S_PRODUCE = 78
C2S_FACTORY = 79
C2S_DISTRICT = 80
C2S_GROUP = 81
C2S_RESIDENT = 83
C2S_NEWSPAPER = 84
C2S_FORUM = 85
C2S_TEXT = 86
C2S_SERVICE = 87
C2S_OPENUI = 88
C2S_ITEMSHOP = 89
C2GS_BAIKE = 92
C2GS_SALE = 94
C2S_NPC_LOOK = 96
C2S_NPC_COMMAND = 97
C2S_NPC_ANSWER = 98
C2S_NPC_BUY = 99
C2S_NPC_TASK = 100
C2S_NPC_GETDETAILS = 101
C2S_NPC_MAKE = 102
C2S_NPC_LEARN_SKILL = 103
C2S_NPC_GETCOST = 104
C2S_NPC_GIVE = 105
C2S_NPC_SELL = 106
C2S_PLAYER_KILL = 107
C2S_NPC_RBCLICK = 108
C2S_NPC_TRADECENTER = 112
C2S_NPC_CHOOSE_ITEM = 113
C2S_NPC_PETADOPT = 114
C2S_NPC_INPUT = 115
C2S_DIANKA = 116
C2S_CONJURE = 125
C2S_NPC_CHOOSE_ITEM_NUM = 127
C2S_SUMM_FREE = 128
C2S_SUMM_VIEW = 129
C2S_SUMM_RENAME = 130
C2S_SUMM_SET_FIGHT = 131
C2S_SUMM_PUT = 132
C2S_SUMM_TAKE = 133
C2S_SUMM_ADDPOINT = 134
C2GS_RIDE = 135
C2S_GETINFO_SUMMON = 144
C2S_GETINFO_ITEM = 145
C2S_MAIL_GET = 146
C2S_GET_CHILD_INFO = 147
C2S_PLAYER_PRIVATE = 148
C2S_PLAYER_CHAT = 149
C2S_GETPLAYERNOTIFY = 150
C2S_PLAYER_WIZARD = 151
C2S_VER = 152
C2S_PLAYER_CMD = 153
C2S_EMS = 154
C2S_GETITEMINFOEXT = 156
C2S_WAR_ATTACK = 160
C2S_WAR_PERFORM = 161
C2S_WAR_SPECIAL = 162
C2S_WAR_DEFEND = 163
C2S_WAR_ESCAPE = 164
C2S_WAR_ITEM = 165
C2S_WAR_SUMMON = 166
C2S_WAR_PROTECT = 167
C2S_WAR_SUMM_ATTACK = 168
C2S_WAR_SUMM_PERFORM = 169
C2S_WAR_SUMM_GUARD = 170
C2S_WAR_SUMM_ITEM = 171
C2S_WAR_SUMM_PROTECT = 172
C2S_WAR_CATCH = 173
C2S_WAR_SUMM_ESCAPE = 174
C2S_WAR_TEAM = 175
C2S_WAR_LOOK = 176
C2S_WAR_SUMMONCHILD = 177
C2S_NPC_TJTRADECENTER = 181
C2S_NPC_FACTORY_OP = 182
C2S_ACHIEVE = 157
C2S_ACHIEVE_BADGE = 158
C2S_COMMON = 192
C2GS_BLOG = 93
C2GS_LOOKFOR_TEAM = 155
C2GS_BEAUTY_VOTE = 58
C2GS_NEW_FRIEND = 57
C2GS_PING = 250
C2GS_ZHIDAO = 90
g_Net = None
g_CmdDelay = None
g_DelayQueue = []
C2GS_CHILD = 91
C2GS_PLAYER_IB = 23
C2GS_OPEN_UI = 88
GS2C_CLIENTUI = 174
NET_FUNCTION_NAME = {1: ('netlogin', 'S2CHello'), 
   2: ('netlogin', 'S2CLoginAccountInfo'), 
   3: ('netlogin', 'S2CLoginRoleInfo'), 
   4: ('netlogin', 'S2CLoginRoleEnter'), 
   5: ('netlogin', 'S2CLoginQueue'), 
   6: ('netlogin', 'S2CLoginPlayerAdd'), 
   7: ('netlogin', 'S2CAccountManage'), 
   30: ('netlogin', 'S2CLoginMessage'), 
   8: ('netlogin', 'S2CLoginError'), 
   9: ('netlogin', 'S2CLoginLocalPW'), 
   10: ('netlogin', 'S2CLoginDelRole'), 
   11: ('netcommon', 'S2CCommon'), 
   14: ('blacklist', 'S2CBlacklist'), 
   15: ('mxgw', 'S2CTime'), 
   16: ('nethero', 'S2CPropInit'), 
   17: ('nethero', 'S2CPropChange', 1), 
   18: ('nethero', 'S2CPropResist'), 
   19: ('nethero', 'S2CPropPower'), 
   20: ('netplayer', 'S2CPropPhoto'), 
   21: ('nethero', 'S2CPropSwitch'), 
   22: ('nethero', 'S2CPropRepute'), 
   23: ('nethero', 'S2CPropXinfa'), 
   24: ('netgoodsserver', 'GS2CGetServerGoodsData'), 
   25: ('nethero', 'S2CPlayerCash'), 
   26: ('nethero', 'S2CPropAdvXinfa'), 
   27: ('nettask', 'S2CJuqingStatus'), 
   28: ('netmail', 'S2CDeathInfo'), 
   29: ('banword', 'S2CBandWord'), 
   32: ('netitem', 'S2CItemKey'), 
   33: ('netitem', 'S2CItemAdd', 1), 
   34: ('netitem', 'S2CItemDel', 1), 
   35: ('netitem', 'S2CItemQuantity', 1), 
   36: ('netitem', 'S2CItemPos', 1), 
   37: ('netitem', 'S2CAskBind'), 
   38: ('netitem', 'S2CItemString'), 
   39: ('netplayer', 'S2CItemLock'), 
   40: ('netmail', 'S2CEms'), 
   41: ('netfindteam', 'GS2CGetData'), 
   42: ('netfindfriend', 'GS2CGetFriendData'), 
   44: ('netcontestbeauty', 'GS2CGetContestBeautyData'), 
   45: ('netrolesale', 'S2CRoleSale'), 
   43: ('netmail', 'S2CChargeHistory'), 
   48: ('netpet', 'S2CSummonInfo', 1), 
   49: ('netpet', 'S2CSummonSkill', 1), 
   50: ('netpet', 'S2CSetFight', 1), 
   51: ('netpet', 'S2CPropView'), 
   52: ('netpet', 'S2CPropState', 1), 
   53: ('netpet', 'S2CSummonKey', 1), 
   54: ('netpet', 'S2CSummEquip', 1), 
   55: ('netride', 'GS2CRideInfo'), 
   56: ('marriage', 'S2CMarriage'), 
   58: ('nethero', 'S2CMobile'), 
   64: ('netplayer', 'S2CSaleHistory'), 
   65: ('nethero', 'S2CSkillLevel'), 
   66: ('netplayer', 'S2CPlayerInfo'), 
   67: ('nethero', 'S2CDesignAdd'), 
   68: ('nethero', 'S2CDesignDel'), 
   69: ('netfriend', 'S2CFriendAdd'), 
   70: ('netfriend', 'S2CFriendDel'), 
   71: ('netfriend', 'S2CFriend'), 
   72: ('nettask', 'S2CTaskAdd'), 
   73: ('nettask', 'S2CTaskRemove'), 
   74: ('netstate', 'S2CStateAdd'), 
   75: ('netstate', 'S2CStateRemove'), 
   77: ('nethero', 'S2CBlock'), 
   78: ('netshop', 'GS2C_SHOP'), 
   79: ('netpet', 'S2CPetRefine'), 
   80: ('room', 'S2CHouse'), 
   81: ('netstorehouse', 'S2CStoreHouse'), 
   82: ('netteam', 'S2CPlayerTeam'), 
   83: ('netplayer', 'S2CPlayerOnSale'), 
   84: ('netgroup', 'S2CGroup'), 
   85: ('netmap', 'S2CMapDel'), 
   86: ('netmap', 'S2CMapTrack'), 
   87: ('netliving', 'S2CProduce'), 
   88: ('netliving', 'S2CMiniGame'), 
   89: ('netopenui', 'S2COpenUI'), 
   90: ('netliving', 'S2CFactory'), 
   91: ('district', 'S2CDistrict'), 
   92: ('netresident', 'S2CResident'), 
   93: ('netplayer', 'S2CDianka'), 
   94: ('netplayer', 'S2CPlayerTrade'), 
   95: ('netgroup', 'S2CStock'), 
   96: ('netmap', 'S2CMapSceneM'), 
   97: ('netmap', 'S2CMapGotoM'), 
   98: ('netmap', 'S2CMapAddPlayer'), 
   99: ('netmap', 'S2CMapAddNpc'), 
   100: ('netmap', 'S2CMapAddGoods'), 
   101: ('netmap', 'S2CMapRefreshNpcSign'), 
   102: ('netmap', 'S2CMapEffect'), 
   103: ('netmap', 'S2CMapTeam'), 
   104: ('netmap', 'S2CMapAddon'), 
   105: ('netmap', 'S2CMapSummon'), 
   106: ('netmap', 'S2CChangeShape'), 
   107: ('netmap', 'S2CMapStore'), 
   108: ('netmap', 'S2CMapHide'), 
   111: ('mask', 'S2CADDMASK'), 
   112: ('netwar', 'S2CWarStart', 16), 
   113: ('netwar', 'S2CWarEnd', 18), 
   114: ('netwar', 'S2CWarTurn', 18), 
   115: ('netwar', 'S2CWarAdd', 18), 
   116: ('netwar', 'S2CWarDel', 18), 
   117: ('netwar', 'S2CWarAttackNormal', 18), 
   118: ('netwar', 'GS2CWarShape', 18), 
   119: ('netwar', 'S2CWarAttackNormalEnd', 18), 
   120: ('netwar', 'S2CWarAttackConverg', 18), 
   121: ('netwar', 'S2CWarProtect', 18), 
   122: ('netwar', 'S2CWarPerform', 18), 
   123: ('netwar', 'S2CWarWState', 18), 
   124: ('netwar', 'S2CWarAddon', 18), 
   125: ('netwar', 'S2CWarHPPercent', 18), 
   126: ('netwar', 'S2CWarONACT', 18), 
   127: ('netwar', 'S2CWarPlayerChat', 18), 
   129: ('netwar', 'S2CWarSummon', 18), 
   130: ('netwar', 'S2CWarSummonCatch', 18), 
   131: ('netwar', 'S2CWarWeather', 18), 
   132: ('netwar', 'S2CWarSign', 16), 
   133: ('netwar', 'S2CWarChildSkill', 16), 
   134: ('netwar', 'S2CWarCalledPet', 16), 
   135: ('netwar', 'S2CChangeAction', 18), 
   144: ('netnpc', 'S2CNpcChat'), 
   145: ('netnpc', 'S2CNpcItemChoose'), 
   147: ('netnpc', 'S2CNpcBuyList'), 
   148: ('netnpc', 'S2CNpcSellList'), 
   149: ('netnpc', 'S2CNpcLearnList'), 
   150: ('netnpc', 'S2CNpcTrade'), 
   151: ('netnpc', 'S2CNpcDetails'), 
   152: ('netnpc', 'S2CNpcChatExt', 16), 
   153: ('netnpc', 'S2CNpcInput'), 
   154: ('netnpc', 'S2CNpcMake'), 
   155: ('netnpc', 'S2CNpcMakeCost'), 
   156: ('netnpc', 'S2CNpcItemBill'), 
   157: ('netnpc', 'S2CNpcTradeCenter'), 
   158: ('netnpc', 'S2CNpcChatJuQing'), 
   159: ('netnpc', 'S2CNpcLearnPerformList'), 
   160: ('netnpc', 'S2CMakeCompleteNotify'), 
   161: ('nethero', 'S2CSummonInfo'), 
   162: ('nethero', 'S2CItemInfo'), 
   163: ('nethero', 'S2CPlayerNotify'), 
   164: ('nethero', 'S2CNotifyExt', 19), 
   165: ('netchat', 'S2CSysNotify', 19), 
   166: ('netmail', 'S2CMail'), 
   167: ('netchat', 'S2CPlayerChat', 16), 
   168: ('netchat', 'S2CWarNotify', 3), 
   169: ('netchat', 'S2CNotify', 19), 
   170: ('mxv', 'S2CVer'), 
   171: ('netmap', 'S2CAddTempNpc'), 
   172: ('netmap', 'S2CFBNpc'), 
   173: ('netchildinfo', 'S2CChildInfo'), 
   174: ('netunpackdialog', 'UnPackDialog'), 
   175: ('nethero', 'S2CSummonInfo6'), 
   177: ('netcountry', 'S2CNewspaper'), 
   178: ('netforum', 'S2CForum'), 
   179: ('nethero', 'S2CServiceAnswer'), 
   180: ('netitemshop', 'S2CItemShop'), 
   181: ('netdreamknow', 'S2CGetDreamKnow'), 
   182: ('netchild', 'S2CChild'), 
   183: ('netbaike', 'S2CBaike'), 
   184: ('netblog', 'S2CBlog'), 
   185: ('netnpc', 'S2CNpcItemDiscount'), 
   186: ('netrichgood', 'S2COpenUpload'), 
   187: ('netrelation', 'S2COpenTeach'), 
   188: ('nettjtradecenter', 'S2CTJTradeCenter'), 
   189: ('netliving', 'S2CFactoryList'), 
   190: ('nethero', 'S2CItemTCInfo'), 
   191: ('netachieve', 'S2CAchieve'), 
   192: ('dlgcalendar', 'S2CTime'), 
   193: ('netachieve', 'S2CAchieveBadge')}
SPECIAL_SERVER_CMD = {167: True, 
   166: True, 
   170: True}

class CNet(CNetClient):

    def __init__(self, ip, port):
        self.m_IP = ip
        self.m_Port = port
        self.m_NetFunction = {}
        self.m_WarCmd = {}
        return

    def Connect(self, ip=None, port=None):
        if not ip:
            ip = self.m_IP
        if not port:
            port = self.m_Port
        CNetClient.Connect(self, ip, port)
        return

    def GetInfo(self):
        if hasattr(self, 'm_Proxy'):
            return '%s  %s:%d' % (self.m_Proxy, self.m_IP, self.m_Port)
        else:
            return '%s:%d' % (self.m_IP, self.m_Port)
        return

    def GetServerName(self):
        import misc, selectserver
        cs = self.m_IP + ' ' + str(self.m_Port)
        servers = misc.OpenFile(selectserver.g_ServerIni, 'rt')
        for server in servers:
            if server.find(cs) != -1:
                infos = server.split(' ')
                return infos[0]

        return ''

    def GetFunc(self, icmd):
        try:
            func = self.m_NetFunction[icmd]
        except KeyError:
            m = NET_FUNCTION_NAME.get(icmd)
            if not m:
                return
            func = getattr(__import__(m[0]), m[1])
            if len(m) > 2:
                attr = m[2]
                if type(attr) == int:
                    self.m_WarCmd[icmd] = attr
                else:
                    func = getattr(func, attr)
            self.m_NetFunction[icmd] = func

        return func

    def OnServerCmd(self, icmd):
        global g_CmdDelay
        global g_DelayQueue
        print 'OnServerCmd: 0x%x' % icmd
        func = self.GetFunc(icmd)
        if func == None:
            print '!!!! func==None, OnServerCmd: 0x%x' % icmd
            return
        import war, netwar, main
        if main.InWar():
            f = self.m_WarCmd.get(icmd)
            if f:
                if f & 2:
                    if war.g_RecordWar:
                        self.WriteRecordFile()
                if f & 1:
                    cmd = war.CCmd(war.ServerCmd)
                    cmd.netobj = CServerCommand(self)
                    cmd.func = func
                    return
        if g_CmdDelay:
            f = self.m_WarCmd.get(icmd)
            if f:
                if f & 16:
                    if icmd == 167:
                        ch = self.UnpackInt(1)
                        if ch in (7, 8, 13):
                            g_DelayQueue.append((CServerCommand(self), ch, func, f))
                        else:
                            func(self, ch)
                    else:
                        if icmd == 112:
                            netwar.StartRecord(self)
                        elif f & 2:
                            if war.g_RecordWar:
                                self.WriteRecordFile()
                        g_DelayQueue.append((CServerCommand(self), None, func, f))
                    return
        func(self)
        return

    def OnSpecialServerCmd(self, icmd):
        if SPECIAL_SERVER_CMD.has_key(icmd):
            self.GetFunc(icmd)(self)
            return True
        else:
            return False
        return

    def OnConnectFail(self):
        print 'OnConnectFail'
        import net
        net.g_Net = None
        return

    def OnError(self, msg=None):
        import commondialog

        def ExitGame(dlg):
            import main
            main.CloseGame()
            return

        def Relogin(dlg):

            def _relogin(obj):
                dlg.m_Lock = None
                import main
                main.Restart()
                return

            dlg.m_Lock = dlg
            dlg.CreatePyCommand(10, _relogin)
            return

        import net
        if net.g_Net.m_Hello:
            import main
            main.HideWindow()
            if msg == None:
                msg = b'\xcd\xf8\xc2\xe7\xb4\xed\xce\xf3\xa3\xac\xc4\xe3\xca\xc7\xb7\xf1\xd2\xaa\xcd\xcb\xb3\xf6\xd3\xce\xcf\xb7\xa3\xbf'
            commondialog.ShowMessageBox(msg, (b'\xcd\xcb\xb3\xf6', b'\xd6\xd8\xd0\xc2\xb5\xc7\xc2\xbc'), (ExitGame, Relogin))
            net.g_Net = None
        else:
            net.g_Net.OnConnectFail()
        return

    def UnpackSigned(self, size):
        n = self.UnpackInt(size)
        m = 128 << (size - 1) * 8
        l = 1 << size * 8
        if size < 4 and n & m:
            return n - l
        return n

    def SendLongText(self, msg):
        g_Net.PacketPrepare(C2S_TEXT)
        g_Net.PacketAddI(1, 1)
        g_Net.PacketSend()
        for p in xrange(0, len(msg), 240):
            g_Net.PacketPrepare(C2S_TEXT)
            g_Net.PacketAddI(2, 1)
            s = msg[p:p + 240]
            g_Net.PacketAddS(s, len(s))
            g_Net.PacketSend()

        g_Net.PacketPrepare(C2S_TEXT)
        g_Net.PacketAddI(3, 1)
        g_Net.PacketSend()
        return


def GetUrlInfo(url):
    if url.find('http://') == 0:
        url = url[7:]
        p = url.find('/')
        if p >= 0:
            server = url[:p]
            file = url[p:]
        else:
            server = url
            file = '/'
        p = server.find(':')
    if p != -1:
        port = int(server[p + 1:])
        server = server[:p]
    else:
        port = 80
    return (
     server, port, file)


g_HttpObjectList = []

class CHttpObject(CNetClient):

    def __init__(self, url, method, callback, *arg):
        print url
        self.m_Callback = callback
        self.m_Arg = arg
        (server, port, file) = GetUrlInfo(url)
        CNetClient.__init__(self)
        self.Connect(server, port)
        info = 'GET %s HTTP/1.1\r\nHost: %s\r\nConnection: Close\r\n\r\n' % (file, server)
        self.NakedSend(info)
        self.m_Data = ''
        self.m_Timer = C_object.CBaseObject(None)

        def NetProcess(obj):
            data = self.Process()
            if data:
                self.m_Data += data
            return ()

        self.m_Timer.CreatePyCommand(0, NetProcess)
        g_HttpObjectList.append(self)
        return

    def Recv(self, data):
        self.m_Data += data
        return

    def OnConnectFail(self):
        print 'http OnConnectFail'
        self.m_Timer = None
        self.m_Callback(self.m_Data, False, *self.m_Arg)
        g_HttpObjectList.remove(self)
        return

    def OnError(self):
        self.m_Timer = None
        succeed = False
        s = self.m_Data.split(' ')
        if len(s) > 2 and s[1][:3] == '200':
            succeed = True
        self.m_Callback(self.m_Data, succeed, *self.m_Arg)
        g_HttpObjectList.remove(self)
        return


def ClearCmdDelay(ob=None):
    global g_CmdDelay
    global g_DelayQueue
    if g_CmdDelay:
        g_CmdDelay.Release()
        g_CmdDelay = None
    for (d, a, f, flag) in g_DelayQueue:
        import war, main
        if main.InWar():
            if flag & 1:
                cmd = war.CCmd(war.ServerCmd)
                cmd.netobj = d
                cmd.func = f
                continue
        if a:
            f(d, a)
        else:
            f(d)

    g_DelayQueue = []
    return


def CreateCmdDelay(t):
    global g_CmdDelay
    if g_CmdDelay:
        return
    g_CmdDelay = C_object.CBaseObject(None)
    g_CmdDelay.CreatePyCommand(t * 30, ClearCmdDelay)
    return


def OpenUrl(url):
    import C_sys
    C_sys.OpenUrl('"' + url + '"')
    return


return
