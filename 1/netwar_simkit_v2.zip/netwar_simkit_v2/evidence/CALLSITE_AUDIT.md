# 客户端调用点与序列化边界审计

## 已核实

- `netwar.py:87-92`：`C2SWarSummPerform(id, target, perform)` 只写 `target:u8` 和 `perform:u16`；形参 `id` 未进入序列化。
- `m4_server.py:5763-5767`：服务端按 `body[0]` 读取 target、`body[1:3]` 读取技能 ID。
- `netwar.py:16-20` 与 `netwar.py:418-424`：`C2SWarLook(id)` 和 `C2SLookWarrior(order)` 均发 opcode 176 + 1 字节。报文形状确定，调用方语义仍需 `warui.py` / `war.py` 佐证。
- `netwar.py:266-279`：opcode 118 `GS2CWarShape` 读取 `id:u8`、`shape:u16`、按 `g_ReplayVer` 分支读取 desc、随后读 NUL 结尾字符串。
- `netwar.py:289-294`：opcode 120 `S2CWarAttackConverg` 读取 `att_id:u8`、`vic_id:u8`。
- `net.py:254-256` 将 118/120 分别路由到上述回调。

## 仍未核实

- 未提供 `warui.py` / `war.py`，无法穷举 `C2SWarSummPerform`、`C2SWarLook`、`C2SLookWarrior` 的外部调用位置与参数来源。
- `PacketAddI` / `UnpackInt` 来自原生扩展 `C_net`，未提供原生实现；小端字段由客户端字段宽度与服务端 `<H` / `<I` 组包/解包交叉确认。
- opcode 118 的 `g_ReplayVer==1/2` 路径分别使用 2/4 字节 desc；抓包覆盖表的 `desc:D` 仅适用于常见非回放路径。
