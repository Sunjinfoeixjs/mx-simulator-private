# 源码验证缺口（修订版）

## 已直接核对的源文件

- 客户端 `netwar.py`、`net.py`
- 服务端模拟器 `m4_server.py`、调试台 `tap.py`
- `netwar_codec.py`、`netwar_schema.json`

## 当前保留的边界

1. `C2SWarSummPerform` 形参 `id` 不在 wire body；不要擅自补字节，也不要把它标成“无用”，它可能由调用上下文使用。
2. Opcode 176 的两个函数都序列化 1 字节；仅凭线序无法判断语义，外部调用模块仍缺。
3. `S2CWarTurn` 的 `lastcmd` 在线字段是 1 字节，客户端将其转成 bool；更细的命令队列语义仍依赖 `war.py`。
4. `S2CWarAdd` 是动态布局；当前 codec 只完整解码常见空 desc 分支，其余保留 raw。
5. `GS2CWarShape` 的 desc 受 `g_ReplayVer` 影响；本次 tap overlay 针对常见非回放分支，并在提示中显式注明边界。
6. `C2SSendSign`（175）的原生 `PacketAddS` 规则仍未确认，编码器不猜字符串编码或长度格式。
7. 本包是源码交叉核对与离线回归；不声称真实客户端现场互操作测试已完成。
