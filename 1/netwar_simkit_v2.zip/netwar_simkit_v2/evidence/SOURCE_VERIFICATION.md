# Netwar 源码交叉验证报告

本报告以本次上传的 `netwar.py`、`net.py`、`m4_server.py`、`tap.py` 为证据。行号是本次上传版本中的行号。

## 客户端上行函数与服务端读取

| 项目 | 客户端证据 | 服务端交叉核对 | 结论 |
|---|---|---|---|
| `C2SWarPerform` / op161 | `netwar.py:8-13` 写 `id:u8`、`perform:u16` | `m4_server.py:8085` 分支读 `body[1:3]` 作为技能 ID；注释说明 `id` 是施法者 | body 固定 3B：施法者 ID + 技能 ID |
| `C2SWarLook` / op176 | `netwar.py:16-20` 写 `id:u8` | `m4_server.py:8135` 把 op176 归入不消耗行动权的忽略分支 | body 固定 1B；模拟服不回应、不推进回合 |
| `C2SLookWarrior` / op176 | `netwar.py:418-423` 写 `order:u8` | 同上，服务端仅看到 opcode 176 和 1B body | 与 `C2SWarLook` 的线序相同；调用语境无法由报文独立识别 |
| `C2SWarSummPerform` / op169 | `netwar.py:87-92` 仅写 `target:u8`、`perform:u16`，形参 `id` 未写入 | `m4_server.py:5763-5767` 读 `body[0]` 为 target、`body[1:3]` 为 pid | body 固定 3B：目标 + 技能 ID；不含 pet ID |
| `C2SWarSummon` / op166 | `netwar.py:50-56` 先写 `op:u8`，仅 `op==0` 时写 `id:u32` | 与客户端函数体一致；工具包按条件长度编码/解码 | body 长 1 或 5B |

## 服务端 S2C 组包与客户端回调

| Opcode / 回调 | 客户端读取 | 服务端组包/序列 | 结论 |
|---|---|---|---|
| 112 `S2CWarStart` | `netwar.py:162-184` 读 `scene:u16 + alineup:u8 + elineup:u8 + type:u8 + x:u16 + y:u16`，并执行 `scene += 1001` | `m4_server.py:2904-2908` 组同一 9B 布局；`m4_server.py:3747` 传 `mapid-1001` | 线序和场景偏移一致 |
| 113 `S2CWarEnd` | `netwar.py:186-196` 结束回调并减少 `g_WarTimes` | `m4_server.py:3044` 发空 body | 空 body；每场只发一次 start/end 配对 |
| 114 `S2CWarTurn` | `netwar.py:199-219` 读 1B 并将 `cmd.lastcmd` 设为 bool，随后 `g_Turn += 1` | `m4_server.py:2941-2943` 组 1B；`m4_server.py:6045-6133` 显示 1 在慢速后缀非空时提前发，0 在最终交回操作权时发 | 字段名/宽度确认；1 不是普遍的宠物等待标志 |
| 115 `S2CWarAdd` | `netwar.py:221-248` 读 id、shape、`UnpackDesc`、位域、owner_id、cls、grade、C 字符串 name | `m4_server.py:2912-2939` 同序组包 | 动态描述体按原始 tail 保留；位域 allied=bit7/type=bit6/child=bit5 |
| 117 `S2CWarAttackNormal` | `netwar.py:258-263` 读 `att_id:u8`、`vic_id:u8` | `m4_server.py:2946-2948` 组同样 2B | 字段名/宽度一致 |
| 118 `GS2CWarShape` | `netwar.py:266-279` 读 id、shape、`UnpackDesc`、C 字符串 name | `net.py:254` 将 118 路由到 `GS2CWarShape` | 不应把 118 命名成 AttackConverg |
| 119 `S2CWarAttackNormalEnd` | `netwar.py:282-286` 读 `id:u8` | `m4_server.py:2982-2984` 组 1B | 一致 |
| 120 `S2CWarAttackConverg` | `netwar.py:289-294` 读 `att_id:u8`、`vic_id:u8` | `net.py:256` 路由 120 到该回调 | tap.py 缺覆盖条目，但客户端字段可确认 |
| 121 `S2CWarProtect` | `netwar.py:297-302` 读 `protector_id:u8`、`protege_id:u8` | `m4_server.py:2951-2953` 组同样 2B | 一致 |
| 122 `S2CWarPerform` | `netwar.py:305-314` 读 `id:u8`、`pid:u16`，再循环 `GetCmdLen()-3` 次读 victim IDs | `m4_server.py:2987-2996` 组 `struct.pack('<BH', wid, pid) + bytes(vic_ids)` | body 为 `3+N` 字节，目标 ID 列表可变长 |
| 123 `S2CWarWState` | `netwar.py:317-325` 读 id、4/2/2 位域和 4B hp_chg | `m4_server.py:2956-2971` 以 `(hurt<<4)|(life<<2)|ward` 和 `<i` 组包 | 字段/位域/有符号整数一致 |
| 124 `S2CWarAddon` | `netwar.py:328-335` 读 id、pid、turn、series | route 在 `net.py:260` | 5B 固定字段 |
| 125 `S2CWarHPPercent` | `netwar.py:358-363` 读 id、per | `m4_server.py:2973-2980` 组 2B | 一致 |
| 129 `S2CWarSummon` | `netwar.py:366-372` 读 id、op | `m4_server.py:2999-3011` 组 2B | 一致 |
| 130 `S2CWarSummonCatch` | `netwar.py:374-380` 读 id、sumid、success | `net.py:265` 路由到该回调 | 3B 固定字段 |
| 127 `S2CWarPlayerChat` | `netwar.py:346-355` 读 channel；channel==2 才读 direction；随后读 NUL 结尾字符串 | `net.py:263` 路由到该回调 | 条件字段 + GBK C 字符串 |
| 132 `S2CWarSign` | `netwar.py:401-406` 读 NUL 结尾字符串 | `net.py:267` 路由到该回调 | GBK C 字符串 |
| 133 `S2CWarChildSkill` | `netwar.py:427-440` 读 grade、count、count 个 u16 skill ID | `net.py:268` 路由到该回调 | body 为 `2+2N` |
| 134 `S2CWarCalledPet` | `netwar.py:444-455` 读 3 个 u8 头字段，再读 count 个 u32 pet ID | `net.py:269` 路由到该回调 | body 为 `3+4N` |
| 135 `S2CChangeAction` | `netwar.py:458-463` 读 id、action 两个 u8 | `net.py:270` 路由到该回调 | 2B 固定字段 |

## 状态机相关的真实顺序

- 开战：`m4_server.py:3747` 发 `WarStart`，随后发我方/敌方 `WarAdd`，宠物存在时在宠物 `WarAdd` 后发 `WarSummon(129)`，最后 `WarTurn(0)`。
- 主角招式：op161 的 `id` 是施法者、`perform` 是招式 ID。模拟服将目标简化为当前存活敌方首个；这是本服策略，不是协议字段的一部分。
- 宠物招式：op169 body 的第一字节是目标，后两字节是技能 ID；服务端使用固定宠物战斗 ID 调用 `_pet_perform`。
- 回合标记：`_resolve_hero_round` 可能先发 `WarTurn(1)` 再结算较慢的单位；宠物命令等待由服务端 `_pending_pet_suffix` 决定。不能仅凭 `lastcmd=1` 切换状态。
- 结束：服务端先发 `WarDel`，再发空 body `WarEnd(113)`，随后场景重同步；奖励在重同步后发送。

## 发现的工具覆盖缺口

原始上传的 `tap.py` `_OV_S2C` 覆盖表没有 op118 / op120，但 `net.py:254-256` 路由表明确包含这两个回调。本修订包的 `revised/tap.py` 已补齐；原始 `tap.py` 保留不变。

## 未声称验证的内容

`warui.py`、`war.py` 等调用方模块及原生 `C_net` 未上传。因此报告不声称已追踪 `C2SWarLook` / `C2SLookWarrior` / `C2SWarSummPerform` 的所有外部调用点，也不声称已反编译验证原生 `PacketAddI` 的实现。核心线序则已与客户端回调及服务端显式打包/读取代码交叉对齐。


## 本次修订补记（netwar_simkit_v2）

- 原始 Library `tap.py` 仍保持不变；本包 `revised/tap.py` 已补上 opcode 118/120 overlay。
- 新增离线回归覆盖：路由名称一致性、118 常见空 desc + NUL 字符串、缺失 NUL 的异常提示、120 固定两字节字段，以及 typed codec 的帧分段/扩展长度/战斗字段测试。
- opcode 118 的回放版本 desc 分支仍不算现场验证完成。
