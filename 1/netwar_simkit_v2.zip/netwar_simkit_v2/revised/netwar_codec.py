"""Source-cross-checked Dream World 2013 netwar wire codec.

Verified against the uploaded client netwar.py/net.py and server
m4_server.py/tap.py. It implements transport framing and the battle body layouts
that can be checked against both sides. It does not implement encryption, the
25-byte naked hello handshake, or dynamic descriptor/string bodies not needed by
the core battle path. Caller modules such as warui.py and the native C_net
primitive implementation were not supplied, so their external call sites and
internal implementation details are not claimed as verified.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import struct


class ProtocolError(ValueError):
    """Malformed or unsupported protocol data."""


class UnverifiedSchemaError(ProtocolError):
    """Raised when code attempts to use a schema that is not source-verified."""


@dataclass(frozen=True)
class Frame:
    direction: str
    opcode: int
    body: bytes

    def __post_init__(self) -> None:
        if self.direction not in ("C2S", "S2C"):
            raise ProtocolError(f"unsupported direction: {self.direction!r}")
        if not 0 <= self.opcode <= 0xFF:
            raise ProtocolError(f"opcode must fit in one byte: {self.opcode}")
        if not isinstance(self.body, bytes):
            raise ProtocolError("frame body must be bytes")


def _check_opcode(opcode: int) -> None:
    if not isinstance(opcode, int) or not 0 <= opcode <= 0xFF:
        raise ProtocolError(f"opcode must be an integer in 0..255, got {opcode!r}")


def _encode_length(length: int) -> bytes:
    if not 0 <= length <= 0xFFFF:
        raise ProtocolError(f"payload too large for the documented length field: {length}")
    if length >= 0xFF:
        return b"\xFF" + struct.pack("<H", length)
    return bytes((length,))


def encode_c2s_frame(opcode: int, body: bytes = b"") -> bytes:
    """Encode C2S frame: [opcode:1][N:1 or FF+u16le][body:N]. N excludes opcode."""
    _check_opcode(opcode)
    if not isinstance(body, (bytes, bytearray, memoryview)):
        raise ProtocolError("body must be bytes-like")
    body = bytes(body)
    return bytes((opcode,)) + _encode_length(len(body)) + body


def encode_s2c_frame(opcode: int, body: bytes = b"") -> bytes:
    """Encode S2C frame: [N:1 or FF+u16le][opcode:1][body], N includes opcode."""
    _check_opcode(opcode)
    if not isinstance(body, (bytes, bytearray, memoryview)):
        raise ProtocolError("body must be bytes-like")
    payload = bytes((opcode,)) + bytes(body)
    return _encode_length(len(payload)) + payload


class StreamFrameDecoder:
    """Incremental stream parser for C2S or S2C frames.

    Call only after the documented 25-byte naked hello exchange has been handled.
    A single feed may return zero, one, or multiple complete frames.
    """
    def __init__(self, direction: str, max_payload: int = 0xFFFF) -> None:
        if direction not in ("C2S", "S2C"):
            raise ProtocolError("direction must be C2S or S2C")
        if not 1 <= max_payload <= 0xFFFF:
            raise ProtocolError("max_payload must be in 1..65535")
        self.direction = direction
        self.max_payload = max_payload
        self._buffer = bytearray()

    @property
    def buffered_bytes(self) -> int:
        return len(self._buffer)

    def reset(self) -> None:
        self._buffer.clear()

    def feed(self, data: bytes) -> List[Frame]:
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise ProtocolError("feed expects bytes-like input")
        self._buffer.extend(data)
        out: List[Frame] = []
        while True:
            parsed = self._try_one()
            if parsed is None:
                break
            frame, consumed = parsed
            del self._buffer[:consumed]
            out.append(frame)
        return out

    def _try_one(self) -> Optional[Tuple[Frame, int]]:
        b = self._buffer
        if self.direction == "C2S":
            # [opcode][N] or [opcode][FF][u16le N][body]
            if len(b) < 2:
                return None
            opcode = b[0]
            marker = b[1]
            if marker == 0xFF:
                if len(b) < 4:
                    return None
                n = struct.unpack_from("<H", b, 2)[0]
                header = 4
            else:
                n = marker
                header = 2
            if n > self.max_payload:
                raise ProtocolError(f"C2S payload length {n} exceeds limit {self.max_payload}")
            total = header + n
            if len(b) < total:
                return None
            return Frame("C2S", opcode, bytes(b[header:total])), total

        # S2C: [N including opcode][opcode][body], extended N when marker == FF.
        if len(b) < 1:
            return None
        marker = b[0]
        if marker == 0xFF:
            if len(b) < 3:
                return None
            n = struct.unpack_from("<H", b, 1)[0]
            header = 3
        else:
            n = marker
            header = 1
        if n < 1:
            raise ProtocolError("S2C payload length must include at least the opcode byte")
        if n > self.max_payload:
            raise ProtocolError(f"S2C payload length {n} exceeds limit {self.max_payload}")
        total = header + n
        if len(b) < total:
            return None
        opcode = b[header]
        return Frame("S2C", opcode, bytes(b[header + 1:total])), total


# C2S command schemas cross-checked against netwar.py function bodies,
# net.py opcode constants, and m4_server.py's dispatch/field reads.
# PacketAddI is implemented by the native C_net extension (not uploaded); the
# critical 16/32-bit fields below agree with the server's explicit <H/<I reads.
C2S_COMMANDS: Dict[str, Dict[str, Any]] = {
    "C2SWarAttack":       {"opcode": 160, "fields": [("id", 1)]},
    "C2SWarPerform":      {"opcode": 161, "fields": [("id", 1), ("perform", 2)]},
    "C2SWarSpecial":      {"opcode": 162, "fields": [("id", 1), ("sid", 2)]},
    "C2SWarDefend":       {"opcode": 163, "fields": []},
    "C2SWarEscape":       {"opcode": 164, "fields": []},
    "C2SWarItem":         {"opcode": 165, "fields": [("id", 1), ("item", 4)]},
    # Client sends id:u32 only for op==0; other op values are a one-byte body.
    "C2SWarSummon":       {"opcode": 166, "fields": None,
                            "conditional_layout": "op:u8; if op==0 then id:u32le",
                            "verification": "source_confirmed_netwar_py"},
    "C2SWarProtect":      {"opcode": 167, "fields": [("id", 1)]},
    "C2SWarSummAttack":   {"opcode": 168, "fields": [("id", 1), ("target", 1)]},
    # netwar.C2SWarSummPerform(id, target, perform) serializes only target:u8
    # and perform:u16. m4_server._finish_pet_turn reads exactly body[0:1] and
    # body[1:3]; `id` is a context argument, not a wire field.
    "C2SWarSummPerform":  {"opcode": 169, "fields": [("target", 1), ("perform", 2)],
                            "context_args_not_on_wire": ["id"],
                            "verification": "source_confirmed_netwar_py_and_m4_server"},
    "C2SWarSummGuard":    {"opcode": 170, "fields": [("id", 1)]},
    "C2SWarSummItem":     {"opcode": 171, "fields": [("id", 1), ("target", 1), ("item", 4)]},
    "C2SWarSummProtect":  {"opcode": 172, "fields": [("id", 1), ("target", 1)]},
    "C2SWarCatch":        {"opcode": 173, "fields": [("id", 1)]},
    "C2SWarSummEscape":   {"opcode": 174, "fields": [("id", 1)]},
    # Client calls PacketAddS(msg, len(msg)); native C_net.PacketAddS encoding
    # is unavailable, so the typed encoder does not guess the byte/string codec.
    "C2SSendSign":       {"opcode": 175, "fields": None, "verification": "native_string_primitive_unavailable"},
    "C2SWarLook":         {"opcode": 176, "fields": [("id", 1)], "variant": "look_by_id",
                            "verification": "function_body_confirmed; external caller module unavailable"},
    "C2SLookWarrior":     {"opcode": 176, "fields": [("order", 1)], "variant": "look_by_order",
                            "verification": "function_body_confirmed; external caller module unavailable"},
    "C2SChild":           {"opcode": 177, "fields": []},
}

OPCODE_TO_COMMANDS: Dict[int, List[str]] = {}
for _name, _schema in C2S_COMMANDS.items():
    OPCODE_TO_COMMANDS.setdefault(_schema["opcode"], []).append(_name)


def _pack_uint(value: int, width: int, field_name: str) -> bytes:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ProtocolError(f"{field_name} must be an integer")
    max_value = (1 << (8 * width)) - 1
    if not 0 <= value <= max_value:
        raise ProtocolError(f"{field_name}={value} does not fit in unsigned {width}-byte field")
    return value.to_bytes(width, "little", signed=False)


def _unpack_uint(body: bytes, offset: int, width: int, field_name: str) -> Tuple[int, int]:
    end = offset + width
    if end > len(body):
        raise ProtocolError(f"body too short for {field_name}: need {width} bytes at offset {offset}")
    return int.from_bytes(body[offset:end], "little", signed=False), end


def encode_c2s_command(name: str, **fields: int) -> bytes:
    """Encode a typed C2S battle command into a complete framed packet.

    C2SSendSign is intentionally excluded because the native C_net PacketAddS
    primitive is unavailable. For opcode 176, choose C2SWarLook (id) or
    C2SLookWarrior (order).
    """
    if name not in C2S_COMMANDS:
        raise ProtocolError(f"unknown C2S command: {name}")
    schema = C2S_COMMANDS[name]
    field_spec = schema["fields"]
    if name == "C2SWarSummon":
        if "op" not in fields:
            raise ProtocolError("C2SWarSummon requires op")
        op = _pack_uint(fields["op"], 1, "op")
        if fields["op"] == 0:
            if set(fields) != {"op", "id"}:
                raise ProtocolError("C2SWarSummon op=0 requires exactly op and id")
            body = op + _pack_uint(fields["id"], 4, "id")
        else:
            if set(fields) != {"op"}:
                raise ProtocolError("C2SWarSummon op!=0 serializes only op")
            body = op
        return encode_c2s_frame(schema["opcode"], body)
    if field_spec is None:
        raise UnverifiedSchemaError(f"{name}: variable/conditional layout is not handled by generic field packing")
    expected = [key for key, _width in field_spec]
    supplied = list(fields.keys())
    missing = [key for key in expected if key not in fields]
    extra = [key for key in supplied if key not in expected]
    if missing or extra:
        raise ProtocolError(f"{name} fields mismatch; missing={missing}, extra={extra}; expected={expected}")
    body = b"".join(_pack_uint(fields[key], width, key) for key, width in field_spec)
    return encode_c2s_frame(schema["opcode"], body)


def decode_c2s_command(opcode: int, body: bytes, variant: Optional[str] = None) -> Dict[str, Any]:
    """Decode a known fixed-layout C2S battle body.

    Opcode 176 is ambiguous and requires variant='C2SWarLook' or
    variant='C2SLookWarrior'. Unknown/dynamic messages are returned as raw.
    """
    names = OPCODE_TO_COMMANDS.get(opcode, [])
    if not names:
        return {"opcode": opcode, "raw_body": bytes(body), "decode_status": "unknown_opcode"}
    if opcode == 176:
        if variant not in ("C2SWarLook", "C2SLookWarrior"):
            return {"opcode": opcode, "variants": names, "raw_body": bytes(body),
                    "decode_status": "ambiguous_variant"}
        name = variant
    else:
        name = names[0]
    schema = C2S_COMMANDS[name]
    field_spec = schema["fields"]
    if name == "C2SWarSummon":
        body = bytes(body)
        if len(body) == 1 and body[0] != 0:
            return {"opcode": opcode, "name": name, "op": body[0],
                    "decode_status": "decoded_conditional_layout"}
        if len(body) == 5 and body[0] == 0:
            return {"opcode": opcode, "name": name, "op": body[0],
                    "id": int.from_bytes(body[1:5], "little"),
                    "decode_status": "decoded_conditional_layout"}
        raise ProtocolError("C2SWarSummon body must be [op] or [op=0][id:u32le]")
    if field_spec is None:
        return {"opcode": opcode, "name": name, "raw_body": bytes(body),
                "decode_status": "unsupported_variable_string"}
    expected_len = sum(width for _key, width in field_spec)
    if len(body) != expected_len:
        raise ProtocolError(f"{name} body length {len(body)} != expected {expected_len}")
    result: Dict[str, Any] = {"opcode": opcode, "name": name, "decode_status": "decoded"}
    offset = 0
    for key, width in field_spec:
        result[key], offset = _unpack_uint(body, offset, width, key)
    if schema.get("verification"):
        result["verification"] = schema["verification"]
    return result


# S2C callback route names cross-checked against net.py:NET_FUNCTION_NAME.
# Dynamic descriptor/string layouts remain raw unless the client read sequence
# and server builder are both straightforward to represent safely.
S2C_WAR_OPCODES = {
    112: "S2CWarStart",
    113: "S2CWarEnd",
    114: "S2CWarTurn",
    115: "S2CWarAdd",
    116: "S2CWarDel",
    117: "S2CWarAttackNormal",
    118: "GS2CWarShape",
    119: "S2CWarAttackNormalEnd",
    120: "S2CWarAttackConverg",
    121: "S2CWarProtect",
    122: "S2CWarPerform",
    123: "S2CWarWState",
    124: "S2CWarAddon",
    125: "S2CWarHPPercent",
    126: "S2CWarONACT",
    127: "S2CWarPlayerChat",
    129: "S2CWarSummon",
    130: "S2CWarSummonCatch",
    131: "S2CWarWeather",
    132: "S2CWarSign",
    133: "S2CWarChildSkill",
    134: "S2CWarCalledPet",
    135: "S2CChangeAction",
}


def _require_len(name: str, body: bytes, expected: int) -> None:
    if len(body) != expected:
        raise ProtocolError(f"{name} body length {len(body)} != expected {expected}")


def decode_s2c_war(opcode: int, body: bytes) -> Dict[str, Any]:
    """Decode battle callbacks using the actual client callback field reads.

    WarAdd and GS2CWarShape support the common empty UnpackDesc tag (0); other
    tagged descriptor variants remain raw because UnpackDesc is a union.
    WarPerform's target list is variable length: all bytes after id:u8 + pid:u16
    are victim IDs.
    """
    body = bytes(body)
    name = S2C_WAR_OPCODES.get(opcode)
    if name is None:
        return {"opcode": opcode, "raw_body": body, "decode_status": "unknown_opcode"}

    if opcode == 112:
        _require_len(name, body, 9)
        scene_field, alineup, elineup, wtype, x, y = struct.unpack("<HBBBHH", body)
        # Client netwar.S2CWarStart sets cmd.scene = wire scene + 1001.
        return {"opcode": opcode, "name": name, "scene_field": scene_field,
                "scene": scene_field + 1001, "client_scene": scene_field + 1001,
                "alineup": alineup, "elineup": elineup, "type": wtype,
                "wtype": wtype, "x": x, "y": y,
                "decode_status": "client_and_server_source_confirmed"}
    if opcode == 113:
        _require_len(name, body, 0)
        return {"opcode": opcode, "name": name, "decode_status": "source_confirmed_empty"}
    if opcode == 114:
        _require_len(name, body, 1)
        raw = body[0]
        lastcmd = bool(raw)
        return {"opcode": opcode, "name": name, "lastcmd": lastcmd,
                "lastcmd_raw": raw, "turn_flag": raw,
                "decode_status": "client_field_confirmed; scheduling_meaning_contextual",
                "note": "Client stores bool(lastcmd). Server emits 1 as an intermediate marker before slower suffix actions, not as a universal pet-pending flag."}
    if opcode == 115:
        if len(body) < 3:
            raise ProtocolError("S2CWarAdd requires at least id(1)+shape(2)")
        wid = body[0]
        shape = int.from_bytes(body[1:3], "little")
        # The server's common empty descriptor is the one-byte UnpackDesc tag 0.
        # In that exact case, all remaining fixed fields and the C string are
        # unambiguous; non-empty descriptor variants stay raw rather than guessed.
        if len(body) >= 4 and body[3] == 0:
            offset = 4
            if len(body) < offset + 4:
                raise ProtocolError("S2CWarAdd empty-desc layout truncated before flags/owner/class/grade")
            flags, owner_id, cls, grade = body[offset:offset+4]
            name_bytes = body[offset+4:]
            nul = name_bytes.find(b"\x00")
            if nul < 0:
                raise ProtocolError("S2CWarAdd name is missing its NUL terminator")
            name_value = name_bytes[:nul].decode("gbk", "replace")
            return {"opcode": opcode, "name": name, "id": wid, "unit_id": wid,
                    "shape": shape, "desc": None, "flags": flags,
                    "allied": bool(flags & 0x80), "type": bool(flags & 0x40),
                    "child": bool(flags & 0x20), "owner_id": owner_id,
                    "cls": cls, "grade": grade, "warrior_name": name_value,
                    "raw_tail": name_bytes[nul+1:],
                    "decode_status": "source_confirmed_empty_desc_layout"}
        return {"opcode": opcode, "name": name, "id": wid, "unit_id": wid,
                "shape": shape, "raw_tail": body[3:],
                "decode_status": "source_confirmed_prefix_dynamic_desc_tail"}
    if opcode == 116:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "id": body[0], "unit_id": body[0],
                "decode_status": "client_field_confirmed"}
    if opcode == 117:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "att_id": body[0], "vic_id": body[1],
                "actor_id": body[0], "target_id": body[1],
                "decode_status": "client_and_server_source_confirmed"}
    if opcode == 118:
        # net.py routes opcode 118 to GS2CWarShape, not WarAttackConverg.
        # For the common empty UnpackDesc tag (0), the following C string is
        # straightforward; other tagged descriptor variants remain raw.
        if len(body) >= 4 and body[3] == 0:
            name_bytes = body[4:]
            nul = name_bytes.find(b"\x00")
            if nul < 0:
                raise ProtocolError("GS2CWarShape name is missing its NUL terminator")
            return {"opcode": opcode, "name": name, "id": body[0],
                    "shape": int.from_bytes(body[1:3], "little"), "desc": None,
                    "warrior_name": name_bytes[:nul].decode("gbk", "replace"),
                    "tail": name_bytes[nul+1:],
                    "decode_status": "source_confirmed_empty_desc_layout"}
        return {"opcode": opcode, "name": name, "raw_body": body,
                "decode_status": "callback_confirmed_dynamic_desc_opaque"}
    if opcode == 119:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "id": body[0], "actor_id": body[0],
                "decode_status": "client_field_confirmed"}
    if opcode == 120:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "att_id": body[0], "vic_id": body[1],
                "decode_status": "client_field_confirmed"}
    if opcode == 121:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "protector_id": body[0],
                "protege_id": body[1], "protected_id": body[1],
                "decode_status": "client_field_confirmed"}
    if opcode == 122:
        if len(body) < 3:
            raise ProtocolError("S2CWarPerform body must contain id(1)+pid(2)")
        wid = body[0]
        pid = int.from_bytes(body[1:3], "little")
        vic_ids = list(body[3:])
        return {"opcode": opcode, "name": name, "id": wid, "pid": pid,
                "vic_ids": vic_ids, "actor_id": wid, "perform_id": pid,
                "target_ids": vic_ids,
                "decode_status": "client_and_server_source_confirmed_variable_targets"}
    if opcode == 123:
        _require_len(name, body, 6)
        wid = body[0]
        flags = body[1]
        hurt = (flags >> 4) & 0x0F
        life = (flags >> 2) & 0x03
        ward = flags & 0x03
        hp_chg = int.from_bytes(body[2:6], "little", signed=True)
        return {"opcode": opcode, "name": name, "id": wid, "unit_id": wid,
                "flags": flags, "hurt": hurt, "life": life, "ward": ward,
                "hp_chg": hp_chg, "hp_change": hp_chg,
                "decode_status": "client_and_server_source_confirmed"}
    if opcode == 124:
        _require_len(name, body, 5)
        wid = body[0]
        pid = int.from_bytes(body[1:3], "little")
        return {"opcode": opcode, "name": name, "id": wid, "pid": pid,
                "turn": body[3], "series": body[4], "decode_status": "client_field_confirmed"}
    if opcode == 125:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "id": body[0], "per": body[1],
                "unit_id": body[0], "hp_percent": body[1],
                "decode_status": "client_and_server_source_confirmed"}
    if opcode == 126:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "id": body[0],
                "decode_status": "client_field_confirmed"}
    if opcode == 127:
        # channel is fixed; direction is present only for channel==2, followed
        # by UnpackString(0), a NUL-terminated GBK C string.
        if not body:
            raise ProtocolError("S2CWarPlayerChat body requires channel(1)")
        channel = body[0]
        offset = 1
        direction = 2
        if channel == 2:
            if len(body) < 2:
                raise ProtocolError("S2CWarPlayerChat channel=2 requires direction(1)")
            direction = body[1]
            offset = 2
        tail = body[offset:]
        nul = tail.find(b"\x00")
        if nul < 0:
            raise ProtocolError("S2CWarPlayerChat word is missing its NUL terminator")
        word = tail[:nul].decode("gbk", "replace")
        return {"opcode": opcode, "name": name, "channel": channel,
                "direction": direction, "word": word, "tail": tail[nul+1:],
                "decode_status": "client_callback_confirmed_cstring"}
    if opcode == 129:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "id": body[0], "op": body[1],
                "unit_id": body[0], "decode_status": "client_and_server_source_confirmed"}
    if opcode == 130:
        _require_len(name, body, 3)
        return {"opcode": opcode, "name": name, "id": body[0], "sumid": body[1],
                "success": body[2], "decode_status": "client_field_confirmed"}
    if opcode == 131:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "weather": body[0],
                "decode_status": "client_field_confirmed"}
    if opcode == 132:
        nul = body.find(b"\x00")
        if nul < 0:
            raise ProtocolError("S2CWarSign msg is missing its NUL terminator")
        return {"opcode": opcode, "name": name,
                "msg": body[:nul].decode("gbk", "replace"),
                "tail": body[nul+1:], "decode_status": "client_callback_confirmed_cstring"}
    if opcode == 133:
        if len(body) < 2:
            raise ProtocolError("S2CWarChildSkill body requires grade(1)+count(1)")
        grade, count = body[0], body[1]
        expected = 2 + count * 2
        _require_len(name, body, expected)
        skills = [int.from_bytes(body[i:i+2], "little") for i in range(2, expected, 2)]
        return {"opcode": opcode, "name": name, "grade": grade,
                "count": count, "skill_ids": skills,
                "decode_status": "client_field_confirmed"}
    if opcode == 134:
        if len(body) < 3:
            raise ProtocolError("S2CWarCalledPet requires call_pet_left/can_call_child/count")
        call_pet_left, can_call_child, count = body[:3]
        expected = 3 + count * 4
        _require_len(name, body, expected)
        called_pets = [int.from_bytes(body[i:i+4], "little")
                       for i in range(3, expected, 4)]
        return {"opcode": opcode, "name": name, "call_pet_left": call_pet_left,
                "can_call_child": can_call_child, "called_pet_num": count,
                "called_pets": called_pets, "decode_status": "client_callback_confirmed"}
    if opcode == 135:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "id": body[0], "action": body[1],
                "decode_status": "client_callback_confirmed"}
    return {"opcode": opcode, "name": name, "raw_body": body, "decode_status": "opaque"}


def encode_c2s_war_summ_perform(target: int, perform: int) -> bytes:
    """Encode the source-confirmed opcode 169 body: target:u8 + perform:u16le.

    The client helper accepts ``(id, target, perform)`` but does not serialize
    ``id``; this helper intentionally has no id parameter.
    """
    return encode_c2s_command("C2SWarSummPerform", target=target, perform=perform)


def encode_c2s_war_look(unit_id: int) -> bytes:
    """Encode C2SWarLook(id), opcode 176, body id:u8."""
    return encode_c2s_command("C2SWarLook", id=unit_id)


def encode_c2s_look_warrior(order: int) -> bytes:
    """Encode C2SLookWarrior(order), opcode 176, body order:u8."""
    return encode_c2s_command("C2SLookWarrior", order=order)


def encode_s2c_war_start(scene: int, alineup: int, elineup: int,
                         wtype: int, x: int, y: int) -> bytes:
    """Encode S2CWarStart. ``scene`` is the raw wire field; client cmd.scene=scene+1001."""
    body = (_pack_uint(scene, 2, "scene") + _pack_uint(alineup, 1, "alineup") +
            _pack_uint(elineup, 1, "elineup") + _pack_uint(wtype, 1, "wtype") +
            _pack_uint(x, 2, "x") + _pack_uint(y, 2, "y"))
    return encode_s2c_frame(112, body)


def encode_s2c_war_end() -> bytes:
    """Encode S2CWarEnd (op113), an empty body."""
    return encode_s2c_frame(113, b"")


def encode_s2c_war_add(wid: int, shape: int, allied: bool, name: str,
                        *, desc: bytes = b"\x00", owner_id: int = 0,
                        cls: int = 0, grade: int = 1,
                        unit_type: bool = False, child: bool = False) -> bytes:
    """Encode S2CWarAdd using the server builder's exact field order.

    ``desc`` must already be encoded as the client's tagged UnpackDesc union;
    the codec does not guess descriptor tags. ``name`` is GBK + NUL, matching
    UnpackString(0). The flag byte is MSB-first: allied=bit7, type=bit6,
    child=bit5.
    """
    if not isinstance(desc, (bytes, bytearray, memoryview)):
        raise ProtocolError("desc must be pre-encoded bytes for UnpackDesc")
    if not desc:
        raise ProtocolError("desc must include a UnpackDesc tag; use b'\x00' for an empty descriptor")
    if not isinstance(name, str):
        raise ProtocolError("name must be str")
    if "\x00" in name:
        raise ProtocolError("name cannot contain NUL because it is a C string")
    flags = (0x80 if allied else 0) | (0x40 if unit_type else 0) | (0x20 if child else 0)
    try:
        name_bytes = name.encode("gbk", "replace") + b"\x00"
    except LookupError as exc:
        raise ProtocolError("GBK codec is unavailable") from exc
    body = (_pack_uint(wid, 1, "wid") + _pack_uint(shape, 2, "shape") + bytes(desc)
            + bytes((flags,)) + _pack_uint(owner_id, 1, "owner_id")
            + _pack_uint(cls, 1, "cls") + _pack_uint(grade, 1, "grade") + name_bytes)
    return encode_s2c_frame(115, body)


def encode_s2c_war_attack_normal(att_id: int, vic_id: int) -> bytes:
    """Encode S2CWarAttackNormal (op117): att_id:u8 + vic_id:u8."""
    body = _pack_uint(att_id, 1, "att_id") + _pack_uint(vic_id, 1, "vic_id")
    return encode_s2c_frame(117, body)


def encode_s2c_war_attack_normal_end(wid: int) -> bytes:
    """Encode S2CWarAttackNormalEnd (op119): id:u8."""
    return encode_s2c_frame(119, _pack_uint(wid, 1, "wid"))


def encode_s2c_war_attack_converg(att_id: int, vic_id: int) -> bytes:
    """Encode S2CWarAttackConverg (op120): att_id:u8 + vic_id:u8."""
    body = _pack_uint(att_id, 1, "att_id") + _pack_uint(vic_id, 1, "vic_id")
    return encode_s2c_frame(120, body)


def encode_s2c_war_hp_percent(wid: int, per: int) -> bytes:
    """Encode S2CWarHPPercent (op125): id:u8 + per:u8."""
    if not isinstance(per, int) or isinstance(per, bool) or not 0 <= per <= 100:
        raise ProtocolError("per must be an integer percentage in 0..100")
    body = _pack_uint(wid, 1, "wid") + _pack_uint(per, 1, "per")
    return encode_s2c_frame(125, body)


def encode_s2c_war_summon(wid: int, op: int = 0) -> bytes:
    """Encode S2CWarSummon (op129): id:u8 + op:u8."""
    body = _pack_uint(wid, 1, "wid") + _pack_uint(op, 1, "op")
    return encode_s2c_frame(129, body)


def encode_s2c_war_addon(wid: int, pid: int, turn: int, series: int) -> bytes:
    """Encode S2CWarAddon (op124): id:u8 + pid:u16le + turn:u8 + series:u8."""
    body = (_pack_uint(wid, 1, "wid") + _pack_uint(pid, 2, "pid")
            + _pack_uint(turn, 1, "turn") + _pack_uint(series, 1, "series"))
    return encode_s2c_frame(124, body)


def encode_s2c_war_summon_catch(wid: int, sumid: int, success: int) -> bytes:
    """Encode S2CWarSummonCatch (op130): id:u8 + sumid:u8 + success:u8."""
    body = (_pack_uint(wid, 1, "wid") + _pack_uint(sumid, 1, "sumid")
            + _pack_uint(success, 1, "success"))
    return encode_s2c_frame(130, body)


def encode_s2c_war_called_pet(call_pet_left: int, can_call_child: int,
                              called_pets: Iterable[int]) -> bytes:
    """Encode S2CWarCalledPet (op134): 3×u8 header + called pet IDs as u32le."""
    pets = list(called_pets)
    if len(pets) > 0xFF:
        raise ProtocolError("called pet count must fit u8")
    body = (_pack_uint(call_pet_left, 1, "call_pet_left")
            + _pack_uint(can_call_child, 1, "can_call_child")
            + _pack_uint(len(pets), 1, "called_pet_num"))
    body += b"".join(_pack_uint(pid, 4, f"called_pets[{i}]") for i, pid in enumerate(pets))
    return encode_s2c_frame(134, body)


def encode_s2c_change_action(wid: int, action: int) -> bytes:
    """Encode S2CChangeAction (op135): id:u8 + action:u8."""
    return encode_s2c_frame(135, _pack_uint(wid, 1, "wid") + _pack_uint(action, 1, "action"))


def encode_s2c_war_sign(msg: str) -> bytes:
    """Encode S2CWarSign (op132) as GBK + NUL, matching UnpackString(0)."""
    if not isinstance(msg, str) or "\x00" in msg:
        raise ProtocolError("msg must be a str without embedded NUL")
    return encode_s2c_frame(132, msg.encode("gbk", "replace") + b"\x00")


def encode_s2c_war_player_chat(channel: int, word: str, direction: int = 2) -> bytes:
    """Encode S2CWarPlayerChat (op127); direction is present only for channel==2."""
    if not isinstance(word, str) or "\x00" in word:
        raise ProtocolError("word must be a str without embedded NUL")
    body = _pack_uint(channel, 1, "channel")
    if channel == 2:
        body += _pack_uint(direction, 1, "direction")
    body += word.encode("gbk", "replace") + b"\x00"
    return encode_s2c_frame(127, body)


def encode_s2c_war_turn(lastcmd: int) -> bytes:
    """Encode S2CWarTurn(lastcmd:u8). The client converts any nonzero to True.

    The value is a command-queue marker; do not equate 1 universally with
    "pet command pending". m4_server emits 1 before a slower suffix batch and
    0 when returning control to the hero menu.
    """
    if isinstance(lastcmd, bool):
        lastcmd = int(lastcmd)
    if lastcmd not in (0, 1):
        raise ProtocolError("simulator should emit lastcmd as 0 or 1")
    return encode_s2c_frame(114, _pack_uint(lastcmd, 1, "lastcmd"))


def encode_s2c_war_perform(wid: int, pid: int,
                           vic_ids: Iterable[int] | int) -> bytes:
    """Encode source-confirmed S2CWarPerform: id:u8 + pid:u16le + vic_ids:u8×N.

    The client decoder loops ``GetCmdLen() - 3`` times, so the target list may
    contain zero, one, or multiple unit IDs. An int is accepted as a convenient
    one-target shorthand; an iterable encodes a multi-target skill.
    """
    if isinstance(vic_ids, int) and not isinstance(vic_ids, bool):
        targets = [vic_ids]
    else:
        try:
            targets = list(vic_ids)
        except TypeError as exc:
            raise ProtocolError("vic_ids must be an integer or iterable of integers") from exc
    # S2C length includes the opcode, so max body is 0xFFFF - 1 bytes.
    if len(targets) > 0xFFFF - 4:
        raise ProtocolError("too many WarPerform victim IDs")
    body = _pack_uint(wid, 1, "wid") + _pack_uint(pid, 2, "pid")
    body += b"".join(_pack_uint(target, 1, f"vic_ids[{i}]") for i, target in enumerate(targets))
    return encode_s2c_frame(122, body)


def encode_s2c_wstate(unit_id: int, hurt: int, life: int, ward: int, hp_change: int) -> bytes:
    """Encode documented WState layout: id, 4/2/2 MSB-first flags, signed 32-bit hp change."""
    if not isinstance(hp_change, int) or isinstance(hp_change, bool) or not -(1 << 31) <= hp_change < (1 << 31):
        raise ProtocolError("hp_change must fit a signed 32-bit integer")
    if not 0 <= hurt <= 0x0F or not 0 <= life <= 0x03 or not 0 <= ward <= 0x03:
        raise ProtocolError("hurt/life/ward exceed 4/2/2-bit widths")
    flags = (hurt << 4) | (life << 2) | ward
    body = _pack_uint(unit_id, 1, "unit_id") + bytes((flags,)) + hp_change.to_bytes(4, "little", signed=True)
    return encode_s2c_frame(123, body)


def encode_s2c_war_del(unit_id: int) -> bytes:
    return encode_s2c_frame(116, _pack_uint(unit_id, 1, "unit_id"))


def encode_s2c_war_protect(protector_id: int, protected_id: int) -> bytes:
    body = _pack_uint(protector_id, 1, "protector_id") + _pack_uint(protected_id, 1, "protected_id")
    return encode_s2c_frame(121, body)
