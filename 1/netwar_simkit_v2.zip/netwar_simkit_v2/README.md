# Netwar Simkit v2 — 协议与抓包调试台修订包

## 本轮变更

1. `revised/tap.py` 增加 S2C opcode 118 `GS2CWarShape` 与 opcode 120 `S2CWarAttackConverg` 的覆盖表。
2. opcode 118 明确注明 `g_ReplayVer` 的 desc 读取分支：常见非回放路径使用 `UnpackDesc`，回放版本 1/2 分别读取 2/4 字节。该覆盖不是对所有回放模式的通用解码器。
3. 保留 `netwar_codec.py` 与 `netwar_schema.json` 作为独立 typed codec/schema；增加覆盖表与客户端路由的回归测试。
4. `backup/tap.py.original` 保留原始调试台副本；未覆盖 Library 中的原文件。

## 测试

在包根目录运行：

```bash
python -m unittest discover -s tests -v
```

测试只使用 Python 标准库；测试导入 `tap.py` 时为 `lzss` 注入了 no-op stub，因为本测试只验证 schema/字段解码，不执行压缩路径。实际运行客户端调试台仍应使用项目原有 `lzss.py`。

## 未声称已解决

- `C2SWarLook` 与 `C2SLookWarrior` 的外部调用语义仍需 `warui.py`/`war.py`。
- 原生 `C_net.PacketAddI`/`UnpackInt` 实现未提供。
- `C2SSendSign` 变长字符串编码不猜测。
- opcode 118 在 `g_ReplayVer==1/2` 的真实回放样本仍需独立验证。
- 本包离线测试通过不等于真实客户端互操作测试通过。
