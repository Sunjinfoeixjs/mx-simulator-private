# netwar 模拟服工具包（保守实现）

## 内容

- `netwar_codec.py`：C2S/S2C 帧编码与增量解码、C2S 战斗指令固定字段编码/解码、部分 S2C 战斗帧解析。
- `war_state_machine.py`：只负责战斗指令阶段的状态机，不实现战斗伤害/速度序/AI。
- `netwar_schema.json`：字段来源与置信度标记。
- `evidence/`：从原始协议提取文件摘录的可追溯证据。
- `tests/`：纯标准库 `unittest`。
- `SOURCE_GAPS.md`：无法从当前可用资料验证的事项。

## 快速测试

```bash
python -m unittest discover -s tests -v
```

## 重要边界

当前可用资料包含协议字段提取 JSON 与模拟服全链路说明文档，但没有原始实现文件 `MX/客户端源码/src/netwar.py`、`src/net.py`、`MX/服务端源码/sim/m4_server.py`、`tap.py`。因此这是可测试的协议工具/状态机骨架，不是已通过原始源码与真实客户端联调的最终实现。

- C2S 帧格式 `[opcode:1][length:1 or FF+u16le][body]`，长度不含 opcode。
- S2C 帧格式 `[length:1 or FF+u16le][opcode:1][body]`，长度含 opcode。
- `S2CWarStart` 的 `scene/alineup/elineup/wtype/x/y` 由现有说明文档明确给出。
- `S2CWarTurn` 的 flag 0/1 含义根据已记录调用时序推断，仍需客户端解码器确认。
- `S2CWarPerform` 只确认字段宽度 `1+2+1`；字段名称/顺序仍属推断，编码接口默认拒绝，测试时必须显式 `confirm_inferred_layout=True`。
- `C2SWarSummPerform` 的函数参数含 `id`，但提取字段表只包含 `target(1)+perform(2)`。编码器按提取的 wire fields 生成，不会擅自补发 `id`。
- Opcode 176 同时对应 `C2SWarLook(id)` 和 `C2SLookWarrior(order)`，解码必须指定变体。
- C2SSendSign(175) 的可变字符串线序未确认，typed encoder 故意不实现；可用通用 `encode_c2s_frame(175, raw_body)` 包装已确认的原始 body。
- 裸 25 字节 Hello 握手必须由握手层单独处理，不送入普通帧解码器。

在连接真实客户端前，先把 `SOURCE_GAPS.md` 中列出的源码放入工程并完成三角对账：客户端 `Unpack*` ↔ 服务端 `build_*` ↔ 调试台 `OVERLAY`。
