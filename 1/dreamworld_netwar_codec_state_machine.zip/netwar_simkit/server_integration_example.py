"""Example adapter for an existing singleplayer simulator.

Integrate after the existing Hello + 25-byte naked handshake has completed.
This example intentionally leaves action resolution to the existing simulator;
it only shows where the frame codec and phase state machine fit.
"""
from collections import deque
from typing import Deque, Optional

from netwar_codec import Frame, StreamFrameDecoder, encode_s2c_frame
from war_state_machine import BattleStateMachine


class FramedConnection:
    def __init__(self) -> None:
        self.decoder = StreamFrameDecoder("C2S")
        self.pending: Deque[Frame] = deque()

    def recv_frame(self, conn, chunk_size: int = 4096) -> Frame:
        """Return one C2S frame, retaining any extra frames from the same recv."""
        while not self.pending:
            chunk = conn.recv(chunk_size)
            if not chunk:
                raise ConnectionError("peer closed while waiting for a C2S frame")
            self.pending.extend(self.decoder.feed(chunk))
        return self.pending.popleft()

    @staticmethod
    def send_s2c(conn, opcode: int, body: bytes = b"") -> None:
        conn.sendall(encode_s2c_frame(opcode, body))


class NetwarSessionAdapter:
    """Minimal glue object; existing simulator owns damage and speed-order rules."""
    def __init__(self) -> None:
        self.frames = FramedConnection()
        self.battle = BattleStateMachine()

    def on_client_frame(self, frame: Frame):
        """Call from the server dispatch loop for a C2S frame during battle."""
        return self.battle.accept_c2s(frame)

    def after_hero_resolution(self, conn, pet_command_pending: bool) -> None:
        """Call only after the simulator emitted action frames and resolved faster units."""
        conn.sendall(self.battle.complete_hero_resolution(
            pet_command_pending=pet_command_pending
        ))

    def after_pet_resolution(self, conn) -> None:
        """Call only after pet action and remaining units are resolved."""
        conn.sendall(self.battle.complete_pet_resolution())

    def send_war_end(self, conn) -> None:
        """Use only after the required WarDel frames; scene resync is separate."""
        conn.sendall(encode_s2c_frame(113, b""))


# Integration notes:
# 1. Keep one FramedConnection per TCP connection; do not instantiate per recv.
# 2. Keep the existing recv_c2s handshake handling for the naked 25-byte response.
# 3. Keep existing _dispatch ordering and DISPATCH_PRE_WAR_OPS protections.
# 4. Emit WarStart only once per battle; send WarTurn(0) after WarStart + WarAdd(s).
# 5. The caller must resolve action frames before calling after_hero_resolution/after_pet_resolution.
# 6. Do not use inferred S2CWarPerform encoder until client source confirms field order.
