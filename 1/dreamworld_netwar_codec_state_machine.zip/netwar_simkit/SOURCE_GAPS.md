# 源码验证缺口

## 当前实际检查到的资料

- `combat_opcodes_fields.json`：C2S 战斗字段提取记录。
- `protocol_functions.json` 的 `netwar.py` 模块：函数参数与抽取字段宽度；不是原始函数体。
- 《模拟服全链路代码解析》：记录模拟服现有行为、帧序、若干已交叉验证的 S2C 布局。

## 缺少的实现源码（必须补充后才能称为“实际调用/序列化已验证”）

1. `MX/客户端源码/src/netwar.py`：检查 `C2SWarSummPerform`、`C2SWarLook`、`C2SLookWarrior` 的调用、参数使用和 `S2CWarStart/Turn/Perform` 回调解码顺序。
2. `MX/客户端源码/src/net.py`：检查 `Pack*`/`Unpack*` 的整数宽度、字节序、字符串约定，以及上行发送函数。
3. `MX/服务端源码/sim/m4_server.py`：核对 `build_war_start`、`build_war_turn`、`build_war_perform`、`build_war_wstate`、`recv_c2s` 和 `_dispatch`。
4. `MX/服务端源码/sim/tap.py`：核对 `OVERLAY` 字段描述是否与组包函数一致。
5. 相关测试：`tests/_test_war_chain.py`、`tests/_test_war2.py`、`tests/_test_battle_skill.py`（以实际存在的测试名为准）。

## 必须保留为待验证的疑点

- `C2SWarSummPerform` 的参数 `id` 出现在函数参数列表，但 wire field extraction 只有 `target(1)`、`perform(2)`。不要自行补字节，也不要假定 `id` 无用。
- Opcode 176 同时有 `C2SWarLook(id)` 和 `C2SLookWarrior(order)`。宽度相同，语义必须靠调用点确认。
- `S2CWarTurn` 的 1-byte flag：文档观察到 0 用于常规玩家命令阶段、1 用于宠物命令挂起阶段；这是按模拟服调用序列归纳，仍应核对客户端回调。
- `S2CWarPerform` 的宽度为 1+2+1，但抽取字段名为空。当前 actor/perform/target 是推断，不是源码确认。
- `S2CWarAdd` 为动态布局；当前仅安全解析前 3 字节 unit_id + shape，后续 desc/bitfield/owner/name 保留 raw。
- 目前编码器对 body 整数按 little-endian 处理；长度扩展字段由说明文档明确为 little-endian。实际 `Pack*`/`Unpack*` 的 body 整数端序仍需用 `src/net.py` 交叉确认。
- C2SSendSign(175) 的变长字符串格式没有实现，避免误加长度前缀或 NUL。

## 不能在当前阶段做的事

- 不能宣称所有字段名都已由原始客户端源码验证。
- 不能把这个状态机当作完整战斗规则引擎；它不实现伤害公式、速度序、敌方 AI、目标合法性或胜负奖励。
- 不能把 `S2CWarPerform` 的推断编码用于真实客户端会话，除非已用原始源码/录像确认并显式开启。
