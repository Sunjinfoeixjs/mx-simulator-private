"""Conservative Dream World 2013 netwar wire codec.

Evidence basis: protocol_functions.json, combat_opcodes_fields.json, and the
available "模拟服全链路代码解析" design notes. The original implementation
sources (client src/netwar.py/src/net.py and server sim/m4_server.py/tap.py)
were not included in the accessible files, so inferred field names are labelled.

This module implements transport framing and only the body schemas supported by
the evidence. It does not implement encryption, the 25-byte naked hello packet,
or unverified variable-string body layouts.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import struct


class ProtocolError(ValueError):
    """Malformed or unsupported protocol data."""


class UnverifiedSchemaError(ProtocolError):
    """Raised when code attempts to use a schema that is not source-verified."""


@dataclass(frozen=True)
class Frame:
    direction: str
    opcode: int
    body: bytes

    def __post_init__(self) -> None:
        if self.direction not in ("C2S", "S2C"):
            raise ProtocolError(f"unsupported direction: {self.direction!r}")
        if not 0 <= self.opcode <= 0xFF:
            raise ProtocolError(f"opcode must fit in one byte: {self.opcode}")
        if not isinstance(self.body, bytes):
            raise ProtocolError("frame body must be bytes")


def _check_opcode(opcode: int) -> None:
    if not isinstance(opcode, int) or not 0 <= opcode <= 0xFF:
        raise ProtocolError(f"opcode must be an integer in 0..255, got {opcode!r}")


def _encode_length(length: int) -> bytes:
    if not 0 <= length <= 0xFFFF:
        raise ProtocolError(f"payload too large for the documented length field: {length}")
    if length >= 0xFF:
        return b"\xFF" + struct.pack("<H", length)
    return bytes((length,))


def encode_c2s_frame(opcode: int, body: bytes = b"") -> bytes:
    """Encode C2S frame: [opcode:1][N:1 or FF+u16le][body:N]. N excludes opcode."""
    _check_opcode(opcode)
    if not isinstance(body, (bytes, bytearray, memoryview)):
        raise ProtocolError("body must be bytes-like")
    body = bytes(body)
    return bytes((opcode,)) + _encode_length(len(body)) + body


def encode_s2c_frame(opcode: int, body: bytes = b"") -> bytes:
    """Encode S2C frame: [N:1 or FF+u16le][opcode:1][body], N includes opcode."""
    _check_opcode(opcode)
    if not isinstance(body, (bytes, bytearray, memoryview)):
        raise ProtocolError("body must be bytes-like")
    payload = bytes((opcode,)) + bytes(body)
    return _encode_length(len(payload)) + payload


class StreamFrameDecoder:
    """Incremental stream parser for C2S or S2C frames.

    Call only after the documented 25-byte naked hello exchange has been handled.
    A single feed may return zero, one, or multiple complete frames.
    """
    def __init__(self, direction: str, max_payload: int = 0xFFFF) -> None:
        if direction not in ("C2S", "S2C"):
            raise ProtocolError("direction must be C2S or S2C")
        if not 1 <= max_payload <= 0xFFFF:
            raise ProtocolError("max_payload must be in 1..65535")
        self.direction = direction
        self.max_payload = max_payload
        self._buffer = bytearray()

    @property
    def buffered_bytes(self) -> int:
        return len(self._buffer)

    def reset(self) -> None:
        self._buffer.clear()

    def feed(self, data: bytes) -> List[Frame]:
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise ProtocolError("feed expects bytes-like input")
        self._buffer.extend(data)
        out: List[Frame] = []
        while True:
            parsed = self._try_one()
            if parsed is None:
                break
            frame, consumed = parsed
            del self._buffer[:consumed]
            out.append(frame)
        return out

    def _try_one(self) -> Optional[Tuple[Frame, int]]:
        b = self._buffer
        if self.direction == "C2S":
            # [opcode][N] or [opcode][FF][u16le N][body]
            if len(b) < 2:
                return None
            opcode = b[0]
            marker = b[1]
            if marker == 0xFF:
                if len(b) < 4:
                    return None
                n = struct.unpack_from("<H", b, 2)[0]
                header = 4
            else:
                n = marker
                header = 2
            if n > self.max_payload:
                raise ProtocolError(f"C2S payload length {n} exceeds limit {self.max_payload}")
            total = header + n
            if len(b) < total:
                return None
            return Frame("C2S", opcode, bytes(b[header:total])), total

        # S2C: [N including opcode][opcode][body], extended N when marker == FF.
        if len(b) < 1:
            return None
        marker = b[0]
        if marker == 0xFF:
            if len(b) < 3:
                return None
            n = struct.unpack_from("<H", b, 1)[0]
            header = 3
        else:
            n = marker
            header = 1
        if n < 1:
            raise ProtocolError("S2C payload length must include at least the opcode byte")
        if n > self.max_payload:
            raise ProtocolError(f"S2C payload length {n} exceeds limit {self.max_payload}")
        total = header + n
        if len(b) < total:
            return None
        opcode = b[header]
        return Frame("S2C", opcode, bytes(b[header + 1:total])), total


# C2S command schemas directly transcribed from combat_opcodes_fields.json.
# Integer fields are treated as unsigned little-endian for this codec; verify
# primitive endianness against src/net.py before connecting to a live client.
C2S_COMMANDS: Dict[str, Dict[str, Any]] = {
    "C2SWarAttack":       {"opcode": 160, "fields": [("id", 1)]},
    "C2SWarPerform":      {"opcode": 161, "fields": [("id", 1), ("perform", 2)]},
    "C2SWarSpecial":      {"opcode": 162, "fields": [("id", 1), ("sid", 2)]},
    "C2SWarDefend":       {"opcode": 163, "fields": []},
    "C2SWarEscape":       {"opcode": 164, "fields": []},
    "C2SWarItem":         {"opcode": 165, "fields": [("id", 1), ("item", 4)]},
    "C2SWarSummon":       {"opcode": 166, "fields": [("op", 1), ("id", 4)]},
    "C2SWarProtect":      {"opcode": 167, "fields": [("id", 1)]},
    "C2SWarSummAttack":   {"opcode": 168, "fields": [("id", 1), ("target", 1)]},
    # The extracted field list omits the function argument `id`. This is kept
    # as an unresolved source discrepancy; do not silently add a wire byte.
    "C2SWarSummPerform":  {"opcode": 169, "fields": [("target", 1), ("perform", 2)],
                            "context_args_not_on_wire": ["id"], "verification": "metadata_only"},
    "C2SWarSummGuard":    {"opcode": 170, "fields": [("id", 1)]},
    "C2SWarSummItem":     {"opcode": 171, "fields": [("id", 1), ("target", 1), ("item", 4)]},
    "C2SWarSummProtect":  {"opcode": 172, "fields": [("id", 1), ("target", 1)]},
    "C2SWarCatch":        {"opcode": 173, "fields": [("id", 1)]},
    "C2SWarSummEscape":   {"opcode": 174, "fields": [("id", 1)]},
    # C2SSendSign (175) uses a variable string; exact PackString/terminator
    # behavior cannot be confirmed without src/net.py and src/netwar.py.
    "C2SSendSign":       {"opcode": 175, "fields": None, "verification": "unsupported_variable_string"},
    "C2SWarLook":         {"opcode": 176, "fields": [("id", 1)], "variant": "look_by_id"},
    "C2SLookWarrior":     {"opcode": 176, "fields": [("order", 1)], "variant": "look_by_order"},
    "C2SChild":           {"opcode": 177, "fields": []},
}

OPCODE_TO_COMMANDS: Dict[int, List[str]] = {}
for _name, _schema in C2S_COMMANDS.items():
    OPCODE_TO_COMMANDS.setdefault(_schema["opcode"], []).append(_name)


def _pack_uint(value: int, width: int, field_name: str) -> bytes:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ProtocolError(f"{field_name} must be an integer")
    max_value = (1 << (8 * width)) - 1
    if not 0 <= value <= max_value:
        raise ProtocolError(f"{field_name}={value} does not fit in unsigned {width}-byte field")
    return value.to_bytes(width, "little", signed=False)


def _unpack_uint(body: bytes, offset: int, width: int, field_name: str) -> Tuple[int, int]:
    end = offset + width
    if end > len(body):
        raise ProtocolError(f"body too short for {field_name}: need {width} bytes at offset {offset}")
    return int.from_bytes(body[offset:end], "little", signed=False), end


def encode_c2s_command(name: str, **fields: int) -> bytes:
    """Encode a typed C2S battle command into a complete framed packet.

    C2SSendSign is intentionally excluded until its variable-string primitive is
    confirmed. For opcode 176, choose C2SWarLook (id) or C2SLookWarrior (order).
    """
    if name not in C2S_COMMANDS:
        raise ProtocolError(f"unknown C2S command: {name}")
    schema = C2S_COMMANDS[name]
    field_spec = schema["fields"]
    if field_spec is None:
        raise UnverifiedSchemaError(f"{name}: variable string encoding is not source-verified")
    expected = [key for key, _width in field_spec]
    supplied = list(fields.keys())
    missing = [key for key in expected if key not in fields]
    extra = [key for key in supplied if key not in expected]
    if missing or extra:
        raise ProtocolError(f"{name} fields mismatch; missing={missing}, extra={extra}; expected={expected}")
    body = b"".join(_pack_uint(fields[key], width, key) for key, width in field_spec)
    return encode_c2s_frame(schema["opcode"], body)


def decode_c2s_command(opcode: int, body: bytes, variant: Optional[str] = None) -> Dict[str, Any]:
    """Decode a known fixed-layout C2S battle body.

    Opcode 176 is ambiguous and requires variant='C2SWarLook' or
    variant='C2SLookWarrior'. Unknown/dynamic messages are returned as raw.
    """
    names = OPCODE_TO_COMMANDS.get(opcode, [])
    if not names:
        return {"opcode": opcode, "raw_body": bytes(body), "decode_status": "unknown_opcode"}
    if opcode == 176:
        if variant not in ("C2SWarLook", "C2SLookWarrior"):
            return {"opcode": opcode, "variants": names, "raw_body": bytes(body),
                    "decode_status": "ambiguous_variant"}
        name = variant
    else:
        name = names[0]
    schema = C2S_COMMANDS[name]
    field_spec = schema["fields"]
    if field_spec is None:
        return {"opcode": opcode, "name": name, "raw_body": bytes(body),
                "decode_status": "unsupported_variable_string"}
    expected_len = sum(width for _key, width in field_spec)
    if len(body) != expected_len:
        raise ProtocolError(f"{name} body length {len(body)} != expected {expected_len}")
    result: Dict[str, Any] = {"opcode": opcode, "name": name, "decode_status": "decoded"}
    offset = 0
    for key, width in field_spec:
        result[key], offset = _unpack_uint(body, offset, width, key)
    if schema.get("verification"):
        result["verification"] = schema["verification"]
    return result


# S2C battle packet IDs and evidence status. The semantic names marked
# inferred are plausible labels based on widths/usage, not verified source truth.
S2C_WAR_OPCODES = {
    112: "S2CWarStart",
    113: "S2CWarEnd",
    114: "S2CWarTurn",
    115: "S2CWarAdd",
    116: "S2CWarDel",
    117: "S2CWarAttackNormal",
    118: "S2CWarAttackConverg",
    119: "S2CWarAttackNormalEnd",
    121: "S2CWarProtect",
    122: "S2CWarPerform",
    123: "S2CWarWState",
    125: "S2CWarHPPercent",
    129: "S2CWarSummon",
}


def _require_len(name: str, body: bytes, expected: int) -> None:
    if len(body) != expected:
        raise ProtocolError(f"{name} body length {len(body)} != expected {expected}")


def decode_s2c_war(opcode: int, body: bytes) -> Dict[str, Any]:
    """Decode S2C battle frames where the available evidence supports it.

    Variable WarAdd data is only partially decoded (unit id + shape). Unknown or
    inferred fields retain raw bytes so they can be rechecked against source.
    """
    body = bytes(body)
    name = S2C_WAR_OPCODES.get(opcode)
    if name is None:
        return {"opcode": opcode, "raw_body": body, "decode_status": "unknown_opcode"}

    if opcode == 112:
        _require_len(name, body, 9)
        scene, alineup, elineup, wtype, x, y = struct.unpack("<HBB BHH", body)
        return {"opcode": opcode, "name": name, "scene": scene, "alineup": alineup,
                "elineup": elineup, "wtype": wtype, "x": x, "y": y,
                "decode_status": "field_names_documented"}
    if opcode == 113:
        _require_len(name, body, 0)
        return {"opcode": opcode, "name": name, "decode_status": "decoded"}
    if opcode == 114:
        _require_len(name, body, 1)
        flag = body[0]
        return {"opcode": opcode, "name": name, "turn_flag": flag,
                "observed_interpretation": {0: "player_command_ready_or_round_complete",
                                            1: "pet_command_pending"}.get(flag, "unknown"),
                "decode_status": "flag_value_observed_semantics_inferred"}
    if opcode == 115:
        if len(body) < 3:
            raise ProtocolError("S2CWarAdd requires at least unit_id(1)+shape(2)")
        return {"opcode": opcode, "name": name, "unit_id": body[0],
                "shape": int.from_bytes(body[1:3], "little"), "raw_tail": body[3:],
                "decode_status": "partial_dynamic_layout"}
    if opcode == 116:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "unit_id": body[0], "decode_status": "first_field_only"}
    if opcode == 117:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "actor_id": body[0], "target_id": body[1],
                "decode_status": "field_names_inferred"}
    if opcode == 118:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "field_0": body[0], "field_1": body[1],
                "decode_status": "raw_semantics_unknown"}
    if opcode == 119:
        _require_len(name, body, 1)
        return {"opcode": opcode, "name": name, "actor_id": body[0],
                "decode_status": "field_name_inferred"}
    if opcode == 121:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "protector_id": body[0], "protected_id": body[1],
                "decode_status": "field_names_documented"}
    if opcode == 122:
        _require_len(name, body, 4)
        actor_id = body[0]
        perform_id = int.from_bytes(body[1:3], "little")
        target_id = body[3]
        return {"opcode": opcode, "name": name, "actor_id": actor_id,
                "perform_id": perform_id, "target_id": target_id,
                "decode_status": "widths_extracted_semantics_inferred"}
    if opcode == 123:
        _require_len(name, body, 6)
        unit_id = body[0]
        flags = body[1]
        hurt = (flags >> 4) & 0x0F
        life = (flags >> 2) & 0x03
        ward = flags & 0x03
        hp_change = int.from_bytes(body[2:6], "little", signed=True)
        return {"opcode": opcode, "name": name, "unit_id": unit_id, "flags": flags,
                "hurt": hurt, "life": life, "ward": ward, "hp_change": hp_change,
                "hp_change_note": "positive means damage according to the project notes",
                "decode_status": "bitfield_layout_documented"}
    if opcode == 125:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "unit_id": body[0], "hp_percent": body[1],
                "decode_status": "field_names_inferred"}
    if opcode == 129:
        _require_len(name, body, 2)
        return {"opcode": opcode, "name": name, "unit_id": body[0], "op": body[1],
                "decode_status": "field_names_documented"}
    return {"opcode": opcode, "name": name, "raw_body": body, "decode_status": "opaque"}


def encode_s2c_war_start(scene: int, alineup: int, elineup: int,
                         wtype: int, x: int, y: int) -> bytes:
    """Encode the documented 9-byte WarStart body and S2C frame (opcode 112)."""
    body = (_pack_uint(scene, 2, "scene") + _pack_uint(alineup, 1, "alineup") +
            _pack_uint(elineup, 1, "elineup") + _pack_uint(wtype, 1, "wtype") +
            _pack_uint(x, 2, "x") + _pack_uint(y, 2, "y"))
    return encode_s2c_frame(112, body)


def encode_s2c_war_turn(turn_flag: int) -> bytes:
    """Encode S2C WarTurn. 0/1 meanings follow observed call sequence; confirm source."""
    return encode_s2c_frame(114, _pack_uint(turn_flag, 1, "turn_flag"))


def encode_s2c_war_perform(actor_id: int, perform_id: int, target_id: int,
                           *, confirm_inferred_layout: bool = False) -> bytes:
    """Encode the 1+2+1 byte WarPerform body.

    Field widths are extracted, but semantic order has not been checked against
    the original client decoder. Requires explicit confirmation to avoid silently
    sending an inferred layout into a real client session.
    """
    if not confirm_inferred_layout:
        raise UnverifiedSchemaError(
            "S2CWarPerform field names/order are inferred; set confirm_inferred_layout=True only for tests"
        )
    body = (_pack_uint(actor_id, 1, "actor_id") + _pack_uint(perform_id, 2, "perform_id") +
            _pack_uint(target_id, 1, "target_id"))
    return encode_s2c_frame(122, body)


def encode_s2c_wstate(unit_id: int, hurt: int, life: int, ward: int, hp_change: int) -> bytes:
    """Encode documented WState layout: id, 4/2/2 MSB-first flags, signed 32-bit hp change."""
    if not isinstance(hp_change, int) or isinstance(hp_change, bool) or not -(1 << 31) <= hp_change < (1 << 31):
        raise ProtocolError("hp_change must fit a signed 32-bit integer")
    if not 0 <= hurt <= 0x0F or not 0 <= life <= 0x03 or not 0 <= ward <= 0x03:
        raise ProtocolError("hurt/life/ward exceed 4/2/2-bit widths")
    flags = (hurt << 4) | (life << 2) | ward
    body = _pack_uint(unit_id, 1, "unit_id") + bytes((flags,)) + hp_change.to_bytes(4, "little", signed=True)
    return encode_s2c_frame(123, body)


def encode_s2c_war_del(unit_id: int) -> bytes:
    return encode_s2c_frame(116, _pack_uint(unit_id, 1, "unit_id"))


def encode_s2c_war_protect(protector_id: int, protected_id: int) -> bytes:
    body = _pack_uint(protector_id, 1, "protector_id") + _pack_uint(protected_id, 1, "protected_id")
    return encode_s2c_frame(121, body)
