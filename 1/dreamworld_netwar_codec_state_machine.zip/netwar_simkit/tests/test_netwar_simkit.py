import unittest

from netwar_codec import (
    Frame, ProtocolError, StreamFrameDecoder, UnverifiedSchemaError,
    decode_c2s_command, decode_s2c_war, encode_c2s_command, encode_c2s_frame,
    encode_s2c_frame, encode_s2c_war_perform, encode_s2c_war_start,
    encode_s2c_war_turn, encode_s2c_wstate,
)
from war_state_machine import BattlePhase, BattleStateMachine


class FramingTests(unittest.TestCase):
    def test_c2s_small_frame_roundtrip_fragmented(self):
        raw = encode_c2s_frame(161, b"\x03\x4d\x00")
        decoder = StreamFrameDecoder("C2S")
        self.assertEqual(decoder.feed(raw[:2]), [])
        frames = decoder.feed(raw[2:])
        self.assertEqual(frames, [Frame("C2S", 161, b"\x03\x4d\x00")])
        self.assertEqual(decoder.buffered_bytes, 0)

    def test_s2c_small_frame_roundtrip(self):
        raw = encode_s2c_frame(114, b"\x01")
        self.assertEqual(raw, b"\x02\x72\x01")
        self.assertEqual(StreamFrameDecoder("S2C").feed(raw), [Frame("S2C", 114, b"\x01")])

    def test_extended_c2s_and_s2c(self):
        body = bytes(range(256))
        c2s = encode_c2s_frame(160, body)
        s2c = encode_s2c_frame(115, body)
        self.assertEqual(c2s[0:2], b"\xA0\xFF")
        self.assertEqual(StreamFrameDecoder("C2S").feed(c2s), [Frame("C2S", 160, body)])
        self.assertEqual(s2c[0], 0xFF)
        self.assertEqual(StreamFrameDecoder("S2C").feed(s2c), [Frame("S2C", 115, body)])

    def test_multiple_frames_in_one_read(self):
        raw = encode_c2s_frame(163) + encode_c2s_frame(164)
        self.assertEqual(StreamFrameDecoder("C2S").feed(raw),
                         [Frame("C2S", 163, b""), Frame("C2S", 164, b"")])


class CommandCodecTests(unittest.TestCase):
    def test_war_perform_command(self):
        raw = encode_c2s_command("C2SWarPerform", id=7, perform=1101)
        frame = StreamFrameDecoder("C2S").feed(raw)[0]
        self.assertEqual(frame, Frame("C2S", 161, b"\x07\x4d\x04"))
        self.assertEqual(decode_c2s_command(161, frame.body)["perform"], 1101)

    def test_summon_perform_preserves_extracted_wire_fields(self):
        raw = encode_c2s_command("C2SWarSummPerform", target=4, perform=1103)
        frame = StreamFrameDecoder("C2S").feed(raw)[0]
        self.assertEqual(frame.body, b"\x04\x4f\x04")
        self.assertEqual(decode_c2s_command(169, frame.body)["target"], 4)
        with self.assertRaises(ProtocolError):
            encode_c2s_command("C2SWarSummPerform", id=250, target=4, perform=1103)

    def test_opcode_176_requires_variant(self):
        self.assertEqual(decode_c2s_command(176, b"\x09")["decode_status"], "ambiguous_variant")
        self.assertEqual(decode_c2s_command(176, b"\x09", "C2SWarLook")["id"], 9)
        self.assertEqual(decode_c2s_command(176, b"\x09", "C2SLookWarrior")["order"], 9)

    def test_variable_string_is_not_guessed(self):
        with self.assertRaises(UnverifiedSchemaError):
            encode_c2s_command("C2SSendSign", msg="hello")


class S2CSchemaTests(unittest.TestCase):
    def test_war_start_documented_layout(self):
        raw = encode_s2c_war_start(scene=2, alineup=1, elineup=3, wtype=0, x=45, y=40)
        frame = StreamFrameDecoder("S2C").feed(raw)[0]
        decoded = decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual((decoded["scene"], decoded["alineup"], decoded["elineup"],
                          decoded["wtype"], decoded["x"], decoded["y"]), (2, 1, 3, 0, 45, 40))

    def test_war_turn_flag(self):
        frame = StreamFrameDecoder("S2C").feed(encode_s2c_war_turn(1))[0]
        self.assertEqual(decode_s2c_war(frame.opcode, frame.body)["turn_flag"], 1)

    def test_wstate_roundtrip(self):
        raw = encode_s2c_wstate(unit_id=250, hurt=1, life=2, ward=1, hp_change=14)
        frame = StreamFrameDecoder("S2C").feed(raw)[0]
        decoded = decode_s2c_war(frame.opcode, frame.body)
        self.assertEqual((decoded["unit_id"], decoded["hurt"], decoded["life"], decoded["ward"],
                          decoded["hp_change"]), (250, 1, 2, 1, 14))

    def test_war_perform_requires_explicit_ack_of_inference(self):
        with self.assertRaises(UnverifiedSchemaError):
            encode_s2c_war_perform(1, 1103, 250)
        raw = encode_s2c_war_perform(1, 1103, 250, confirm_inferred_layout=True)
        frame = StreamFrameDecoder("S2C").feed(raw)[0]
        self.assertEqual(decode_s2c_war(frame.opcode, frame.body)["perform_id"], 1103)


class StateMachineTests(unittest.TestCase):
    def setUp(self):
        self.sm = BattleStateMachine()

    def test_hero_then_pet_then_player_turn(self):
        start = encode_s2c_war_start(2, 1, 1, 0, 45, 40)
        start_frame = StreamFrameDecoder("S2C").feed(start)[0]
        self.sm.observe_s2c(start_frame)
        self.assertEqual(self.sm.phase, BattlePhase.SETUP)
        self.sm.mark_initial_command_ready()
        self.assertEqual(self.sm.phase, BattlePhase.PLAYER_COMMAND)

        attack = StreamFrameDecoder("C2S").feed(encode_c2s_command("C2SWarAttack", id=1))[0]
        self.assertTrue(self.sm.accept_c2s(attack)["accepted"])
        self.assertEqual(self.sm.phase, BattlePhase.RESOLVING_HERO)
        self.sm.complete_hero_resolution(pet_command_pending=True)
        self.assertEqual(self.sm.phase, BattlePhase.PET_COMMAND)

        pet = StreamFrameDecoder("C2S").feed(encode_c2s_command("C2SWarSummAttack", id=250, target=1))[0]
        self.assertTrue(self.sm.accept_c2s(pet)["accepted"])
        self.assertEqual(self.sm.phase, BattlePhase.RESOLVING_PET)
        self.sm.complete_pet_resolution()
        self.assertEqual(self.sm.phase, BattlePhase.PLAYER_COMMAND)

    def test_pet_command_rejected_before_pet_phase(self):
        self.sm.mark_battle_started(scene=2)
        self.sm.mark_initial_command_ready()
        pet = StreamFrameDecoder("C2S").feed(encode_c2s_command("C2SWarSummAttack", id=250, target=1))[0]
        result = self.sm.accept_c2s(pet)
        self.assertFalse(result["accepted"])

    def test_non_turn_look_does_not_consume_action(self):
        self.sm.mark_battle_started(scene=2)
        self.sm.mark_initial_command_ready()
        look = StreamFrameDecoder("C2S").feed(encode_c2s_command("C2SWarLook", id=2))[0]
        result = self.sm.accept_c2s(look)
        self.assertTrue(result["accepted"])
        self.assertFalse(result["turn_consumed"])
        self.assertEqual(self.sm.phase, BattlePhase.PLAYER_COMMAND)

    def test_end_battle(self):
        self.sm.mark_battle_started(scene=2)
        frame = StreamFrameDecoder("S2C").feed(encode_s2c_frame(113))[0]
        self.sm.observe_s2c(frame)
        self.assertEqual(self.sm.phase, BattlePhase.ENDED)
        self.assertFalse(self.sm.active)


if __name__ == "__main__":
    unittest.main(verbosity=2)
