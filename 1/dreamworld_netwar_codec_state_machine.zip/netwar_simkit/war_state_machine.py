"""Conservative turn orchestration state machine for a Dream World 2013 sim server.

This coordinates command phases only. It intentionally does not invent combat
math, speed order, AI, target validation, or damage rules. The caller is
responsible for resolving actions and sending animation/state frames in the
verified order before calling complete_*().
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from netwar_codec import (
    Frame, ProtocolError, StreamFrameDecoder, decode_c2s_command, decode_s2c_war,
    encode_s2c_frame, encode_s2c_war_turn,
)


class BattlePhase(str, Enum):
    OUTSIDE = "outside"
    SETUP = "setup"
    PLAYER_COMMAND = "player_command"
    RESOLVING_HERO = "resolving_hero"
    PET_COMMAND = "pet_command"
    RESOLVING_PET = "resolving_pet"
    ENDED = "ended"


@dataclass
class BattleUnit:
    unit_id: int
    shape: Optional[int] = None
    raw_add_body: bytes = b""
    last_wstate: Optional[Dict[str, Any]] = None


@dataclass
class BattleStateMachine:
    """State machine with explicit server-side resolution boundaries.

    Observed protocol contract: WarStart=112 once per battle, WarTurn=114 is
    the command-phase gate, WarEnd=113 ends the battle. WarTurn(1) is treated
    as a pet-command wait because the project notes describe that call sequence;
    this semantic should be confirmed against src/netwar.py before live use.
    """
    phase: BattlePhase = BattlePhase.OUTSIDE
    scene: Optional[int] = None
    turn_flag: Optional[int] = None
    units: Dict[int, BattleUnit] = field(default_factory=dict)
    turn_events: int = 0
    current_action: Optional[Dict[str, Any]] = None
    history: List[Dict[str, Any]] = field(default_factory=list)
    anomalies: List[str] = field(default_factory=list)

    # These are intentionally configurable: opcode 173 is named Catch and is
    # treated as a hero action here, despite broad notes referring to 168-174 as
    # the asynchronous pet range. Verify this classification from netwar.py.
    hero_action_opcodes = frozenset((160, 161, 162, 163, 164, 165, 166, 167, 173, 177))
    pet_action_opcodes = frozenset((168, 169, 170, 171, 172, 174))
    non_turn_opcodes = frozenset((175, 176))

    @property
    def active(self) -> bool:
        return self.phase not in (BattlePhase.OUTSIDE, BattlePhase.ENDED)

    def observe_s2c(self, frame: Frame) -> Dict[str, Any]:
        if frame.direction != "S2C":
            raise ProtocolError("observe_s2c expects an S2C frame")
        event = decode_s2c_war(frame.opcode, frame.body)
        op = frame.opcode

        if op == 112:
            if self.active:
                self.anomalies.append("WarStart received while a battle is already active; source contract says once per battle")
            self.scene = event.get("scene")
            self.units.clear()
            self.current_action = None
            self.turn_flag = None
            self.phase = BattlePhase.SETUP
        elif op == 115:
            if "unit_id" in event:
                uid = event["unit_id"]
                unit = self.units.get(uid) or BattleUnit(unit_id=uid)
                unit.shape = event.get("shape", unit.shape)
                unit.raw_add_body = bytes(frame.body)
                self.units[uid] = unit
        elif op == 116:
            self.units.pop(event.get("unit_id"), None)
        elif op == 114:
            self.turn_events += 1
            self.turn_flag = event.get("turn_flag")
            if self.turn_flag == 1:
                self.phase = BattlePhase.PET_COMMAND
            elif self.turn_flag == 0:
                self.phase = BattlePhase.PLAYER_COMMAND
            else:
                self.anomalies.append(f"unrecognized WarTurn flag: {self.turn_flag}")
        elif op in (117, 122):
            self.current_action = event
            # A visible action frame means action resolution/animation is underway.
            if self.active:
                self.phase = BattlePhase.RESOLVING_HERO if self.phase == BattlePhase.PLAYER_COMMAND else self.phase
        elif op == 123:
            unit = self.units.get(event.get("unit_id"))
            if unit is not None:
                unit.last_wstate = event
        elif op == 119:
            event["action_animation_finished"] = True
        elif op == 113:
            self.phase = BattlePhase.ENDED
            self.current_action = None
            # Preserve the last known units for inspection; caller can call reset().
        self.history.append(event)
        return event

    def accept_c2s(self, frame: Frame) -> Dict[str, Any]:
        """Validate and record a client command; does not execute combat rules."""
        if frame.direction != "C2S":
            raise ProtocolError("accept_c2s expects a C2S frame")
        op = frame.opcode
        if not self.active:
            return {"accepted": False, "reason": "no_active_battle", "opcode": op}
        if op in self.non_turn_opcodes:
            # Look/team chat do not consume an action according to project notes.
            result = {"accepted": True, "turn_consumed": False, "opcode": op,
                      "reason": "non_turn_command", "raw_body": frame.body}
            self.history.append(result)
            return result
        if op in self.hero_action_opcodes:
            if self.phase != BattlePhase.PLAYER_COMMAND:
                return {"accepted": False, "turn_consumed": False, "opcode": op,
                        "reason": f"hero_command_not_allowed_in_{self.phase.value}"}
            command = decode_c2s_command(op, frame.body)
            self.current_action = {"side": "hero", "command": command}
            self.phase = BattlePhase.RESOLVING_HERO
            result = {"accepted": True, "turn_consumed": True, "side": "hero", "command": command}
            self.history.append(result)
            return result
        if op in self.pet_action_opcodes:
            if self.phase != BattlePhase.PET_COMMAND:
                return {"accepted": False, "turn_consumed": False, "opcode": op,
                        "reason": f"pet_command_not_allowed_in_{self.phase.value}"}
            command = decode_c2s_command(op, frame.body)
            self.current_action = {"side": "pet", "command": command}
            self.phase = BattlePhase.RESOLVING_PET
            result = {"accepted": True, "turn_consumed": True, "side": "pet", "command": command}
            self.history.append(result)
            return result
        result = {"accepted": False, "turn_consumed": False, "opcode": op,
                  "reason": "not_a_known_battle_command", "raw_body": frame.body}
        self.history.append(result)
        return result

    def complete_hero_resolution(self, *, pet_command_pending: bool) -> bytes:
        """Call after speed-order resolution and all action frames have been sent.

        Returns the WarTurn frame that opens either the pet command phase (1) or
        the next player command phase (0). This function does not resolve enemies.
        """
        if self.phase != BattlePhase.RESOLVING_HERO:
            raise ProtocolError(f"cannot complete hero resolution from {self.phase.value}")
        flag = 1 if pet_command_pending else 0
        frame = encode_s2c_war_turn(flag)
        self.turn_flag = flag
        self.phase = BattlePhase.PET_COMMAND if pet_command_pending else BattlePhase.PLAYER_COMMAND
        self.current_action = None
        return frame

    def complete_pet_resolution(self) -> bytes:
        """Call after pet action + remaining slower units have been resolved."""
        if self.phase != BattlePhase.RESOLVING_PET:
            raise ProtocolError(f"cannot complete pet resolution from {self.phase.value}")
        frame = encode_s2c_war_turn(0)
        self.turn_flag = 0
        self.phase = BattlePhase.PLAYER_COMMAND
        self.current_action = None
        return frame

    def mark_battle_started(self, scene: int) -> None:
        """For a server implementation that owns state before emitting WarStart."""
        if self.active:
            raise ProtocolError("battle already active; do not emit WarStart twice")
        self.scene = scene
        self.units.clear()
        self.current_action = None
        self.turn_flag = None
        self.phase = BattlePhase.SETUP

    def mark_initial_command_ready(self) -> bytes:
        if self.phase != BattlePhase.SETUP:
            raise ProtocolError(f"cannot open initial command phase from {self.phase.value}")
        self.turn_flag = 0
        self.phase = BattlePhase.PLAYER_COMMAND
        return encode_s2c_war_turn(0)

    def reset(self) -> None:
        self.phase = BattlePhase.OUTSIDE
        self.scene = None
        self.turn_flag = None
        self.units.clear()
        self.current_action = None
        self.history.clear()
        self.anomalies.clear()
        self.turn_events = 0
